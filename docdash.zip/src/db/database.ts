import Database from 'better-sqlite3';
import path from 'node:path';
import type {
  Clinic,
  ClinicAppState,
  Doctor,
  DoctorStatus,
  QueueToken,
  ShiftType,
  SmsNotification,
  SmsNotificationType,
} from '../types/clinic';
import {
  calculateEWMA,
  computeTokenMetrics,
  getActiveConsultationToken,
  getOrderedWaitingTokens,
  haversineDistanceMeters,
  isWithinCheckInRadius,
  shouldTriggerProximityAlert,
} from '../utils/queueEstimator';
import {
  SEED_CLINICS,
  SEED_DOCTORS,
  SEED_SMS,
  SEED_TOKENS,
  generateSeedHeatmap,
} from './seed';

const DB_PATH = path.resolve(process.cwd(), 'docdash.db');

export class ClinicDatabase {
  private db: Database.Database;
  private heatmapCache = generateSeedHeatmap();

  constructor(dbPath = DB_PATH) {
    this.db = new Database(dbPath);
    this.db.pragma('journal_mode = WAL');
    this.initSchema();
    this.seedIfEmpty();
  }

  private initSchema(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS clinics (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        district TEXT NOT NULL,
        address TEXT NOT NULL,
        phone TEXT NOT NULL,
        open_hours TEXT NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        image_url TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS doctors (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        credentials TEXT NOT NULL,
        specialty TEXT NOT NULL,
        clinic_id TEXT NOT NULL,
        clinic_name TEXT NOT NULL,
        consultation_fee INTEGER NOT NULL,
        base_avg_minutes INTEGER NOT NULL,
        dynamic_avg_minutes INTEGER NOT NULL,
        recent_durations TEXT NOT NULL,
        status TEXT NOT NULL,
        delay_offset_minutes INTEGER NOT NULL DEFAULT 0,
        shift_availability TEXT NOT NULL,
        FOREIGN KEY (clinic_id) REFERENCES clinics(id)
      );

      CREATE TABLE IF NOT EXISTS queue_tokens (
        id TEXT PRIMARY KEY,
        doctor_id TEXT NOT NULL,
        clinic_id TEXT NOT NULL,
        token_number INTEGER NOT NULL,
        queue_rank INTEGER NOT NULL,
        patient_name TEXT NOT NULL,
        patient_phone TEXT NOT NULL,
        shift TEXT NOT NULL,
        status TEXT NOT NULL,
        priority TEXT NOT NULL DEFAULT 'normal',
        notes TEXT NOT NULL DEFAULT '',
        prescription_notes TEXT,
        prescription_file_name TEXT,
        prescription_file_data TEXT,
        booked_at TEXT NOT NULL,
        called_at TEXT,
        completed_at TEXT,
        checked_in_at TEXT,
        check_in_distance_meters INTEGER,
        FOREIGN KEY (doctor_id) REFERENCES doctors(id),
        FOREIGN KEY (clinic_id) REFERENCES clinics(id)
      );

      CREATE TABLE IF NOT EXISTS sms_notifications (
        id TEXT PRIMARY KEY,
        token_id TEXT NOT NULL,
        token_number INTEGER NOT NULL,
        doctor_id TEXT NOT NULL,
        doctor_name TEXT NOT NULL,
        clinic_name TEXT NOT NULL,
        patient_phone TEXT NOT NULL,
        message TEXT NOT NULL,
        sent_at TEXT NOT NULL,
        type TEXT NOT NULL
      );
    `);
  }

  private seedIfEmpty(): void {
    const countRow = this.db
      .prepare('SELECT COUNT(*) as count FROM clinics')
      .get() as { count: number };
    if (countRow.count === 0) {
      this.resetToSeed();
    }
  }

  public resetToSeed(): ClinicAppState {
    const tx = this.db.transaction(() => {
      this.db.exec(`
        DELETE FROM sms_notifications;
        DELETE FROM queue_tokens;
        DELETE FROM doctors;
        DELETE FROM clinics;
      `);

      const insertClinic = this.db.prepare(`
        INSERT INTO clinics (id, name, district, address, phone, open_hours, latitude, longitude, image_url)
        VALUES (@id, @name, @district, @address, @phone, @openHours, @latitude, @longitude, @imageUrl)
      `);
      for (const c of SEED_CLINICS) {
        insertClinic.run(c);
      }

      const insertDoctor = this.db.prepare(`
        INSERT INTO doctors (
          id, name, credentials, specialty, clinic_id, clinic_name,
          consultation_fee, base_avg_minutes, dynamic_avg_minutes,
          recent_durations, status, delay_offset_minutes, shift_availability
        ) VALUES (
          @id, @name, @credentials, @specialty, @clinicId, @clinicName,
          @consultationFee, @baseAvgMinutes, @dynamicAvgMinutes,
          @recentDurations, @status, @delayOffsetMinutes, @shiftAvailability
        )
      `);
      for (const d of SEED_DOCTORS) {
        insertDoctor.run({
          ...d,
          recentDurations: JSON.stringify(d.recentDurations),
          shiftAvailability: JSON.stringify(d.shiftAvailability),
        });
      }

      const insertToken = this.db.prepare(`
        INSERT INTO queue_tokens (
          id, doctor_id, clinic_id, token_number, queue_rank,
          patient_name, patient_phone, shift, status, priority, notes,
          prescription_notes, prescription_file_name, prescription_file_data,
          booked_at, called_at, completed_at, checked_in_at, check_in_distance_meters
        ) VALUES (
          @id, @doctorId, @clinicId, @tokenNumber, @queueRank,
          @patientName, @patientPhone, @shift, @status, @priority, @notes,
          @prescriptionNotes, @prescriptionFileName, @prescriptionFileData,
          @bookedAt, @calledAt, @completedAt, @checkedInAt, @checkInDistanceMeters
        )
      `);
      for (const t of SEED_TOKENS) {
        insertToken.run(t);
      }

      const insertSms = this.db.prepare(`
        INSERT INTO sms_notifications (
          id, token_id, token_number, doctor_id, doctor_name,
          clinic_name, patient_phone, message, sent_at, type
        ) VALUES (
          @id, @tokenId, @tokenNumber, @doctorId, @doctorName,
          @clinicName, @patientPhone, @message, @sentAt, @type
        )
      `);
      for (const s of SEED_SMS) {
        insertSms.run(s);
      }
    });

    tx();
    return this.getFullState();
  }

  public getClinics(): Clinic[] {
    const rows = this.db.prepare('SELECT * FROM clinics').all() as Array<
      Record<string, unknown>
    >;
    return rows.map((r) => ({
      id: String(r.id),
      name: String(r.name),
      district: String(r.district),
      address: String(r.address),
      phone: String(r.phone),
      openHours: String(r.open_hours),
      latitude: Number(r.latitude),
      longitude: Number(r.longitude),
      imageUrl: String(r.image_url),
    }));
  }

  public getDoctors(): Doctor[] {
    const rows = this.db.prepare('SELECT * FROM doctors').all() as Array<
      Record<string, unknown>
    >;
    return rows.map((r) => ({
      id: String(r.id),
      name: String(r.name),
      credentials: String(r.credentials),
      specialty: String(r.specialty) as Doctor['specialty'],
      clinicId: String(r.clinic_id),
      clinicName: String(r.clinic_name),
      consultationFee: Number(r.consultation_fee),
      baseAvgMinutes: Number(r.base_avg_minutes),
      dynamicAvgMinutes: Number(r.dynamic_avg_minutes),
      recentDurations: JSON.parse(String(r.recent_durations)) as number[],
      status: String(r.status) as DoctorStatus,
      delayOffsetMinutes: Number(r.delay_offset_minutes),
      shiftAvailability: JSON.parse(
        String(r.shift_availability)
      ) as ShiftType[],
    }));
  }

  public getTokens(): QueueToken[] {
    const rows = this.db
      .prepare('SELECT * FROM queue_tokens ORDER BY queue_rank ASC, token_number ASC')
      .all() as Array<Record<string, unknown>>;
    return rows.map((r) => ({
      id: String(r.id),
      doctorId: String(r.doctor_id),
      clinicId: String(r.clinic_id),
      tokenNumber: Number(r.token_number),
      queueRank: Number(r.queue_rank),
      patientName: String(r.patient_name),
      patientPhone: String(r.patient_phone),
      shift: String(r.shift) as ShiftType,
      status: String(r.status) as QueueToken['status'],
      priority: String(r.priority) as QueueToken['priority'],
      notes: String(r.notes ?? ''),
      prescriptionNotes: r.prescription_notes
        ? String(r.prescription_notes)
        : null,
      prescriptionFileName: r.prescription_file_name
        ? String(r.prescription_file_name)
        : null,
      prescriptionFileData: r.prescription_file_data
        ? String(r.prescription_file_data)
        : null,
      bookedAt: String(r.booked_at),
      calledAt: r.called_at ? String(r.called_at) : null,
      completedAt: r.completed_at ? String(r.completed_at) : null,
      checkedInAt: r.checked_in_at ? String(r.checked_in_at) : null,
      checkInDistanceMeters:
        r.check_in_distance_meters !== null &&
        r.check_in_distance_meters !== undefined
          ? Number(r.check_in_distance_meters)
          : null,
    }));
  }

  public getSmsNotifications(): SmsNotification[] {
    const rows = this.db
      .prepare('SELECT * FROM sms_notifications ORDER BY sent_at DESC LIMIT 50')
      .all() as Array<Record<string, unknown>>;
    return rows.map((r) => ({
      id: String(r.id),
      tokenId: String(r.token_id),
      tokenNumber: Number(r.token_number),
      doctorId: String(r.doctor_id),
      doctorName: String(r.doctor_name),
      clinicName: String(r.clinic_name),
      patientPhone: String(r.patient_phone),
      message: String(r.message),
      sentAt: String(r.sent_at),
      type: String(r.type) as SmsNotificationType,
    }));
  }

  public getFullState(): ClinicAppState {
    return {
      clinics: this.getClinics(),
      doctors: this.getDoctors(),
      tokens: this.getTokens(),
      smsNotifications: this.getSmsNotifications(),
      heatmap: this.heatmapCache,
      serverTime: new Date().toISOString(),
    };
  }

  private addSms(entry: Omit<SmsNotification, 'id' | 'sentAt'>): void {
    const existing =
      entry.type === 'proximity_alert'
        ? this.db
            .prepare(
              'SELECT id FROM sms_notifications WHERE token_id = ? AND type = ?'
            )
            .get(entry.tokenId, 'proximity_alert')
        : null;
    if (existing) {
      return;
    }

    const id = `sms-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const sentAt = new Date().toISOString();
    this.db
      .prepare(
        `INSERT INTO sms_notifications (
          id, token_id, token_number, doctor_id, doctor_name,
          clinic_name, patient_phone, message, sent_at, type
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        id,
        entry.tokenId,
        entry.tokenNumber,
        entry.doctorId,
        entry.doctorName,
        entry.clinicName,
        entry.patientPhone,
        entry.message,
        sentAt,
        entry.type
      );
  }

  private evaluateProximityNotifications(doctorId: string): void {
    const doctor = this.getDoctors().find((d) => d.id === doctorId);
    if (!doctor) return;
    const allTokens = this.getTokens();
    const waiting = getOrderedWaitingTokens(doctorId, allTokens);

    for (const token of waiting) {
      const metrics = computeTokenMetrics(token, doctor, allTokens);
      if (shouldTriggerProximityAlert(metrics.patientsAhead, token.status)) {
        const aheadLabel =
          metrics.patientsAhead === 1
            ? '1 patient ahead'
            : `${metrics.patientsAhead} patients ahead`;
        this.addSms({
          tokenId: token.id,
          tokenNumber: token.tokenNumber,
          doctorId: doctor.id,
          doctorName: doctor.name,
          clinicName: doctor.clinicName,
          patientPhone: token.patientPhone,
          type: 'proximity_alert',
          message: `Please arrive at the clinic now! Token #${token.tokenNumber} for ${doctor.name} (${doctor.clinicName}) has ${aheadLabel} — Est. Wait: ${metrics.estimatedWaitMinutes} mins.`,
        });
      }
    }
  }

  public bookToken(input: {
    doctorId: string;
    patientName: string;
    patientPhone: string;
    shift: ShiftType;
    notes?: string;
    priority?: 'normal' | 'emergency';
  }): { token: QueueToken; state: ClinicAppState } {
    const doctor = this.getDoctors().find((d) => d.id === input.doctorId);
    if (!doctor) {
      throw new Error('Selected doctor not found.');
    }

    const cleanName = input.patientName.trim();
    const cleanPhone = input.patientPhone.trim();
    if (!cleanName || !cleanPhone) {
      throw new Error('Patient name and phone number are required.');
    }

    const doctorTokens = this.getTokens().filter(
      (t) => t.doctorId === doctor.id
    );
    const maxTokenNumber = doctorTokens.reduce(
      (max, t) => Math.max(max, t.tokenNumber),
      0
    );
    const nextTokenNumber = maxTokenNumber + 1;

    let queueRank = nextTokenNumber * 100;
    const priority = input.priority === 'emergency' ? 'emergency' : 'normal';
    if (priority === 'emergency') {
      const waiting = getOrderedWaitingTokens(doctor.id, doctorTokens);
      const minWaitingRank =
        waiting.length > 0 ? waiting[0].queueRank : nextTokenNumber * 100;
      queueRank = minWaitingRank - 10;
    } else {
      const maxRank = doctorTokens.reduce(
        (max, t) => Math.max(max, t.queueRank),
        0
      );
      queueRank = Math.max(nextTokenNumber * 100, maxRank + 100);
    }

    const token: QueueToken = {
      id: `tok-${doctor.id.replace('doc-', '')}-${nextTokenNumber}-${Date.now().toString(36)}`,
      doctorId: doctor.id,
      clinicId: doctor.clinicId,
      tokenNumber: nextTokenNumber,
      queueRank,
      patientName: cleanName,
      patientPhone: cleanPhone,
      shift: input.shift,
      status: 'waiting',
      priority,
      notes: (input.notes ?? '').trim(),
      prescriptionNotes: null,
      prescriptionFileName: null,
      prescriptionFileData: null,
      bookedAt: new Date().toISOString(),
      calledAt: null,
      completedAt: null,
      checkedInAt: null,
      checkInDistanceMeters: null,
    };

    this.db
      .prepare(
        `INSERT INTO queue_tokens (
          id, doctor_id, clinic_id, token_number, queue_rank,
          patient_name, patient_phone, shift, status, priority, notes,
          prescription_notes, prescription_file_name, prescription_file_data,
          booked_at, called_at, completed_at, checked_in_at, check_in_distance_meters
        ) VALUES (
          @id, @doctorId, @clinicId, @tokenNumber, @queueRank,
          @patientName, @patientPhone, @shift, @status, @priority, @notes,
          @prescriptionNotes, @prescriptionFileName, @prescriptionFileData,
          @bookedAt, @calledAt, @completedAt, @checkedInAt, @checkInDistanceMeters
        )`
      )
      .run(token);

    const allTokens = this.getTokens();
    const metrics = computeTokenMetrics(token, doctor, allTokens);

    this.addSms({
      tokenId: token.id,
      tokenNumber: token.tokenNumber,
      doctorId: doctor.id,
      doctorName: doctor.name,
      clinicName: doctor.clinicName,
      patientPhone: token.patientPhone,
      type: 'booking_confirmed',
      message:
        priority === 'emergency'
          ? `URGENT TRIAGE: Token #${token.tokenNumber} escalated to priority front-of-line for ${doctor.name} at ${doctor.clinicName}.`
          : `Confirmed: Token #${token.tokenNumber} (${token.shift} shift) with ${doctor.name} at ${doctor.clinicName}. Est. Wait: ${metrics.estimatedWaitMinutes} mins.`,
    });

    this.evaluateProximityNotifications(doctor.id);

    return {
      token,
      state: this.getFullState(),
    };
  }

  private recordConsultationDuration(
    doctor: Doctor,
    durationMinutes: number
  ): void {
    const safeDuration = Math.min(30, Math.max(5, Math.round(durationMinutes)));
    const updatedHistory = [...doctor.recentDurations, safeDuration].slice(-5);
    const nextEwma = calculateEWMA(updatedHistory, doctor.baseAvgMinutes);
    this.db
      .prepare(
        'UPDATE doctors SET recent_durations = ?, dynamic_avg_minutes = ? WHERE id = ?'
      )
      .run(JSON.stringify(updatedHistory), nextEwma, doctor.id);
  }

  public callNextPatient(
    doctorId: string,
    completedDurationMinutes?: number
  ): ClinicAppState {
    const doctor = this.getDoctors().find((d) => d.id === doctorId);
    if (!doctor) throw new Error('Doctor not found.');

    const allTokens = this.getTokens();
    const active = getActiveConsultationToken(doctorId, allTokens);
    const now = new Date().toISOString();

    if (active) {
      this.db
        .prepare(
          `UPDATE queue_tokens SET status = 'completed', completed_at = ? WHERE id = ?`
        )
        .run(now, active.id);
      if (completedDurationMinutes && Number.isFinite(completedDurationMinutes)) {
        this.recordConsultationDuration(doctor, completedDurationMinutes);
      }
    }

    const waiting = getOrderedWaitingTokens(doctorId, this.getTokens());
    const nextToken = waiting[0];
    if (nextToken) {
      this.db
        .prepare(
          `UPDATE queue_tokens SET status = 'in_consultation', called_at = ? WHERE id = ?`
        )
        .run(now, nextToken.id);
      this.db
        .prepare(
          `UPDATE doctors SET status = 'In Consultation' WHERE id = ?`
        )
        .run(doctorId);

      this.addSms({
        tokenId: nextToken.id,
        tokenNumber: nextToken.tokenNumber,
        doctorId: doctor.id,
        doctorName: doctor.name,
        clinicName: doctor.clinicName,
        patientPhone: nextToken.patientPhone,
        type: 'called',
        message: `Now Calling Token #${nextToken.tokenNumber}: Please enter ${doctor.name}'s consultation room at ${doctor.clinicName}.`,
      });
    }

    this.evaluateProximityNotifications(doctorId);
    return this.getFullState();
  }

  public markCurrentCompleted(input: {
    doctorId: string;
    durationMinutes?: number;
    prescriptionNotes?: string;
    prescriptionFileName?: string | null;
    prescriptionFileData?: string | null;
  }): ClinicAppState {
    const doctor = this.getDoctors().find((d) => d.id === input.doctorId);
    if (!doctor) throw new Error('Doctor not found.');

    const active = getActiveConsultationToken(input.doctorId, this.getTokens());
    if (!active) {
      throw new Error('No patient is currently in consultation.');
    }

    const now = new Date().toISOString();
    this.db
      .prepare(
        `UPDATE queue_tokens
         SET status = 'completed',
             completed_at = ?,
             prescription_notes = COALESCE(?, prescription_notes),
             prescription_file_name = COALESCE(?, prescription_file_name),
             prescription_file_data = COALESCE(?, prescription_file_data)
         WHERE id = ?`
      )
      .run(
        now,
        input.prescriptionNotes?.trim() || null,
        input.prescriptionFileName || null,
        input.prescriptionFileData || null,
        active.id
      );

    if (input.durationMinutes && Number.isFinite(input.durationMinutes)) {
      this.recordConsultationDuration(doctor, input.durationMinutes);
    }

    this.evaluateProximityNotifications(input.doctorId);
    return this.getFullState();
  }

  public addDelay(doctorId: string, minutes = 10): ClinicAppState {
    const doctor = this.getDoctors().find((d) => d.id === doctorId);
    if (!doctor) throw new Error('Doctor not found.');

    const nextOffset = Math.max(0, doctor.delayOffsetMinutes + minutes);
    this.db
      .prepare(
        `UPDATE doctors SET delay_offset_minutes = ?, status = 'Delayed' WHERE id = ?`
      )
      .run(nextOffset, doctorId);

    const waiting = getOrderedWaitingTokens(doctorId, this.getTokens());
    const nextWaiting = waiting[0];
    if (nextWaiting) {
      this.addSms({
        tokenId: nextWaiting.id,
        tokenNumber: nextWaiting.tokenNumber,
        doctorId: doctor.id,
        doctorName: doctor.name,
        clinicName: doctor.clinicName,
        patientPhone: nextWaiting.patientPhone,
        type: 'delay_notice',
        message: `Schedule Update: ${doctor.name} is delayed by +${minutes} mins (Total offset: +${nextOffset} mins). Your live token wait has been recalculated.`,
      });
    }

    return this.getFullState();
  }

  public updateDoctorStatus(
    doctorId: string,
    status: DoctorStatus,
    resetDelay = false
  ): ClinicAppState {
    const doctor = this.getDoctors().find((d) => d.id === doctorId);
    if (!doctor) throw new Error('Doctor not found.');

    const nextOffset = resetDelay ? 0 : doctor.delayOffsetMinutes;
    this.db
      .prepare(
        'UPDATE doctors SET status = ?, delay_offset_minutes = ? WHERE id = ?'
      )
      .run(status, nextOffset, doctorId);

    return this.getFullState();
  }

  public skipAbsentToken(tokenId: string): ClinicAppState {
    const token = this.getTokens().find((t) => t.id === tokenId);
    if (!token) throw new Error('Token not found.');

    const wasActive = token.status === 'in_consultation';
    this.db
      .prepare(`UPDATE queue_tokens SET status = 'skipped' WHERE id = ?`)
      .run(tokenId);

    if (wasActive) {
      return this.callNextPatient(token.doctorId);
    }

    this.evaluateProximityNotifications(token.doctorId);
    return this.getFullState();
  }

  public requeueSkippedToken(tokenId: string): ClinicAppState {
    const token = this.getTokens().find((t) => t.id === tokenId);
    if (!token) throw new Error('Token not found.');

    const doctorTokens = this.getTokens().filter(
      (t) => t.doctorId === token.doctorId
    );
    const maxRank = doctorTokens.reduce(
      (max, t) => Math.max(max, t.queueRank),
      0
    );

    this.db
      .prepare(
        `UPDATE queue_tokens SET status = 'waiting', queue_rank = ? WHERE id = ?`
      )
      .run(maxRank + 100, tokenId);

    this.evaluateProximityNotifications(token.doctorId);
    return this.getFullState();
  }

  public checkInTokenByGeolocation(
    tokenId: string,
    latitude: number,
    longitude: number
  ): {
    checkedIn: boolean;
    distanceMeters: number;
    state: ClinicAppState;
  } {
    const token = this.getTokens().find((t) => t.id === tokenId);
    if (!token) throw new Error('Token not found.');
    const clinic = this.getClinics().find((c) => c.id === token.clinicId);
    if (!clinic) throw new Error('Clinic not found.');

    const distanceMeters = haversineDistanceMeters(
      clinic.latitude,
      clinic.longitude,
      latitude,
      longitude
    );

    if (!isWithinCheckInRadius(distanceMeters)) {
      return {
        checkedIn: false,
        distanceMeters,
        state: this.getFullState(),
      };
    }

    this.db
      .prepare(
        `UPDATE queue_tokens
         SET status = CASE WHEN status = 'waiting' THEN 'checked_in' ELSE status END,
             checked_in_at = ?,
             check_in_distance_meters = ?
         WHERE id = ?`
      )
      .run(new Date().toISOString(), distanceMeters, tokenId);

    return {
      checkedIn: true,
      distanceMeters,
      state: this.getFullState(),
    };
  }

  public attachPrescription(input: {
    tokenId: string;
    prescriptionNotes: string;
    prescriptionFileName?: string | null;
    prescriptionFileData?: string | null;
  }): ClinicAppState {
    const token = this.getTokens().find((t) => t.id === input.tokenId);
    if (!token) throw new Error('Token not found.');

    this.db
      .prepare(
        `UPDATE queue_tokens
         SET prescription_notes = ?,
             prescription_file_name = COALESCE(?, prescription_file_name),
             prescription_file_data = COALESCE(?, prescription_file_data)
         WHERE id = ?`
      )
      .run(
        input.prescriptionNotes.trim(),
        input.prescriptionFileName || null,
        input.prescriptionFileData || null,
        input.tokenId
      );

    return this.getFullState();
  }
}

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import type {
  ClinicAppState,
  DoctorStatus,
  QueueToken,
  ShiftType,
} from '../types/clinic';

const MY_TOKENS_STORAGE_KEY = 'docdash_my_token_ids_v1';

interface BookTokenPayload {
  doctorId: string;
  patientName: string;
  patientPhone: string;
  shift: ShiftType;
  notes?: string;
}

interface EmergencyPayload {
  doctorId: string;
  patientName: string;
  patientPhone: string;
  shift?: ShiftType;
  notes?: string;
}

interface CompleteCurrentPayload {
  doctorId: string;
  durationMinutes?: number;
  prescriptionNotes?: string;
  prescriptionFileName?: string | null;
  prescriptionFileData?: string | null;
}

interface ClinicContextValue {
  state: ClinicAppState | null;
  loading: boolean;
  error: string | null;
  wsConnected: boolean;
  myTokenIds: string[];
  trackTokenId: (tokenId: string) => void;
  untrackTokenId: (tokenId: string) => void;
  refreshState: () => Promise<void>;
  bookToken: (payload: BookTokenPayload) => Promise<QueueToken>;
  escalateEmergency: (payload: EmergencyPayload) => Promise<QueueToken>;
  callNextPatient: (
    doctorId: string,
    durationMinutes?: number
  ) => Promise<void>;
  markCurrentCompleted: (payload: CompleteCurrentPayload) => Promise<void>;
  addDoctorDelay: (doctorId: string, minutes?: number) => Promise<void>;
  updateDoctorStatus: (
    doctorId: string,
    status: DoctorStatus,
    resetDelay?: boolean
  ) => Promise<void>;
  skipAbsentToken: (tokenId: string) => Promise<void>;
  requeueSkippedToken: (tokenId: string) => Promise<void>;
  checkInWithCoordinates: (
    tokenId: string,
    latitude: number,
    longitude: number
  ) => Promise<{ checkedIn: boolean; distanceMeters: number; message: string }>;
  attachPrescription: (payload: {
    tokenId: string;
    prescriptionNotes: string;
    prescriptionFileName?: string | null;
    prescriptionFileData?: string | null;
  }) => Promise<void>;
  resetDemoData: () => Promise<void>;
}

const ClinicContext = createContext<ClinicContextValue | null>(null);

function loadStoredTokenIds(): string[] {
  try {
    const raw = localStorage.getItem(MY_TOKENS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed)
      ? parsed.filter((x): x is string => typeof x === 'string')
      : [];
  } catch {
    return [];
  }
}

export function ClinicProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<ClinicAppState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [wsConnected, setWsConnected] = useState(false);
  const [myTokenIds, setMyTokenIds] = useState<string[]>(loadStoredTokenIds);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(MY_TOKENS_STORAGE_KEY, JSON.stringify(myTokenIds));
    } catch {
      // Ignore storage quota errors
    }
  }, [myTokenIds]);

  const applyNewState = useCallback((nextState: ClinicAppState) => {
    setState(nextState);
    setError(null);
    setLoading(false);
    // Prune stored IDs only if they no longer exist after a demo reset
    setMyTokenIds((prev) => {
      const validIds = new Set(nextState.tokens.map((t) => t.id));
      const filtered = prev.filter((id) => validIds.has(id));
      return filtered.length === prev.length ? prev : filtered;
    });
  }, []);

  const refreshState = useCallback(async () => {
    try {
      const res = await fetch('/api/state');
      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }
      const data = (await res.json()) as ClinicAppState;
      applyNewState(data);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Unable to reach clinic server'
      );
      setLoading(false);
    }
  }, [applyNewState]);

  useEffect(() => {
    void refreshState();

    let unmounted = false;
    function connectWs() {
      if (unmounted) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      const socket = new WebSocket(wsUrl);
      wsRef.current = socket;

      socket.onopen = () => {
        if (!unmounted) setWsConnected(true);
      };

      socket.onmessage = (event) => {
        try {
          const parsed = JSON.parse(String(event.data)) as {
            type: string;
            data?: ClinicAppState;
          };
          if (
            (parsed.type === 'state:init' || parsed.type === 'state:updated') &&
            parsed.data
          ) {
            applyNewState(parsed.data);
          }
        } catch {
          // Ignore malformed frame
        }
      };

      socket.onclose = () => {
        if (!unmounted) {
          setWsConnected(false);
          reconnectTimerRef.current = window.setTimeout(connectWs, 2500);
        }
      };

      socket.onerror = () => {
        socket.close();
      };
    }

    connectWs();

    // Lightweight 3-second polling fallback to guarantee cross-screen consistency
    const pollId = window.setInterval(() => {
      void refreshState();
    }, 3000);

    return () => {
      unmounted = true;
      window.clearInterval(pollId);
      if (reconnectTimerRef.current !== null) {
        window.clearTimeout(reconnectTimerRef.current);
      }
      wsRef.current?.close();
    };
  }, [applyNewState, refreshState]);

  const trackTokenId = useCallback((tokenId: string) => {
    setMyTokenIds((prev) =>
      prev.includes(tokenId) ? prev : [tokenId, ...prev]
    );
  }, []);

  const untrackTokenId = useCallback((tokenId: string) => {
    setMyTokenIds((prev) => prev.filter((id) => id !== tokenId));
  }, []);

  const postJson = useCallback(
    async <T,>(url: string, body?: unknown): Promise<T> => {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || 'Request failed');
      }
      return json as T;
    },
    []
  );

  const bookToken = useCallback(
    async (payload: BookTokenPayload): Promise<QueueToken> => {
      const res = await postJson<{ token: QueueToken; state: ClinicAppState }>(
        '/api/tokens',
        payload
      );
      applyNewState(res.state);
      trackTokenId(res.token.id);
      return res.token;
    },
    [applyNewState, postJson, trackTokenId]
  );

  const escalateEmergency = useCallback(
    async (payload: EmergencyPayload): Promise<QueueToken> => {
      const res = await postJson<{ token: QueueToken; state: ClinicAppState }>(
        '/api/tokens/emergency',
        payload
      );
      applyNewState(res.state);
      return res.token;
    },
    [applyNewState, postJson]
  );

  const callNextPatient = useCallback(
    async (doctorId: string, durationMinutes?: number) => {
      const nextState = await postJson<ClinicAppState>(
        `/api/doctors/${doctorId}/call-next`,
        { durationMinutes }
      );
      applyNewState(nextState);
    },
    [applyNewState, postJson]
  );

  const markCurrentCompleted = useCallback(
    async (payload: CompleteCurrentPayload) => {
      const nextState = await postJson<ClinicAppState>(
        `/api/doctors/${payload.doctorId}/complete-current`,
        payload
      );
      applyNewState(nextState);
    },
    [applyNewState, postJson]
  );

  const addDoctorDelay = useCallback(
    async (doctorId: string, minutes = 10) => {
      const nextState = await postJson<ClinicAppState>(
        `/api/doctors/${doctorId}/delay`,
        { minutes }
      );
      applyNewState(nextState);
    },
    [applyNewState, postJson]
  );

  const updateDoctorStatus = useCallback(
    async (doctorId: string, status: DoctorStatus, resetDelay = false) => {
      const nextState = await postJson<ClinicAppState>(
        `/api/doctors/${doctorId}/status`,
        { status, resetDelay }
      );
      applyNewState(nextState);
    },
    [applyNewState, postJson]
  );

  const skipAbsentToken = useCallback(
    async (tokenId: string) => {
      const nextState = await postJson<ClinicAppState>(
        `/api/tokens/${tokenId}/skip`
      );
      applyNewState(nextState);
    },
    [applyNewState, postJson]
  );

  const requeueSkippedToken = useCallback(
    async (tokenId: string) => {
      const nextState = await postJson<ClinicAppState>(
        `/api/tokens/${tokenId}/requeue`
      );
      applyNewState(nextState);
    },
    [applyNewState, postJson]
  );

  const checkInWithCoordinates = useCallback(
    async (tokenId: string, latitude: number, longitude: number) => {
      const res = await fetch(`/api/tokens/${tokenId}/checkin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ latitude, longitude }),
      });
      const json = await res.json();
      if (!res.ok) {
        return {
          checkedIn: false,
          distanceMeters: Number(json.distanceMeters ?? 0),
          message:
            json.error ||
            'Outside 500m clinic check-in perimeter. Move closer to check in.',
        };
      }
      applyNewState(json.state as ClinicAppState);
      return {
        checkedIn: true,
        distanceMeters: Number(json.distanceMeters),
        message: `Checked in automatically (${json.distanceMeters}m from clinic).`,
      };
    },
    [applyNewState]
  );

  const attachPrescription = useCallback(
    async (payload: {
      tokenId: string;
      prescriptionNotes: string;
      prescriptionFileName?: string | null;
      prescriptionFileData?: string | null;
    }) => {
      const nextState = await postJson<ClinicAppState>(
        `/api/tokens/${payload.tokenId}/prescription`,
        payload
      );
      applyNewState(nextState);
    },
    [applyNewState, postJson]
  );

  const resetDemoData = useCallback(async () => {
    const nextState = await postJson<ClinicAppState>('/api/demo/reset');
    setMyTokenIds([]);
    applyNewState(nextState);
  }, [applyNewState, postJson]);

  const value = useMemo<ClinicContextValue>(
    () => ({
      state,
      loading,
      error,
      wsConnected,
      myTokenIds,
      trackTokenId,
      untrackTokenId,
      refreshState,
      bookToken,
      escalateEmergency,
      callNextPatient,
      markCurrentCompleted,
      addDoctorDelay,
      updateDoctorStatus,
      skipAbsentToken,
      requeueSkippedToken,
      checkInWithCoordinates,
      attachPrescription,
      resetDemoData,
    }),
    [
      state,
      loading,
      error,
      wsConnected,
      myTokenIds,
      trackTokenId,
      untrackTokenId,
      refreshState,
      bookToken,
      escalateEmergency,
      callNextPatient,
      markCurrentCompleted,
      addDoctorDelay,
      updateDoctorStatus,
      skipAbsentToken,
      requeueSkippedToken,
      checkInWithCoordinates,
      attachPrescription,
      resetDemoData,
    ]
  );

  return (
    <ClinicContext.Provider value={value}>{children}</ClinicContext.Provider>
  );
}

export function useClinic() {
  const ctx = useContext(ClinicContext);
  if (!ctx) {
    throw new Error('useClinic must be used within ClinicProvider');
  }
  return ctx;
}

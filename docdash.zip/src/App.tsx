import React, { useState } from 'react';
import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom';
import { ClinicProvider } from './context/ClinicContext';
import { Layout } from './components/Layout';
import { BookingModal } from './components/BookingModal';
import { DoctorDirectoryPage } from './components/DoctorDirectoryPage';
import { LiveQueueBoardPage } from './components/LiveQueueBoardPage';
import { MyAppointmentsPage } from './components/MyAppointmentsPage';
import { DoctorConsolePage } from './components/DoctorConsolePage';
import { WaitHeatmapPage } from './components/WaitHeatmapPage';

function AppRoutes() {
  const [bookingOpen, setBookingOpen] = useState(false);
  const [bookingDoctorId, setBookingDoctorId] = useState<string | null>(null);

  function openBookingForDoctor(doctorId?: string) {
    setBookingDoctorId(doctorId ?? null);
    setBookingOpen(true);
  }

  return (
    <Layout onOpenBooking={openBookingForDoctor}>
      <Routes>
        <Route
          path="/"
          element={<DoctorDirectoryPage onBookDoctor={openBookingForDoctor} />}
        />
        <Route
          path="/queue-board"
          element={<LiveQueueBoardPage onBookDoctor={openBookingForDoctor} />}
        />
        <Route
          path="/my-appointments"
          element={
            <MyAppointmentsPage onOpenBooking={() => openBookingForDoctor()} />
          }
        />
        <Route path="/doctor-console" element={<DoctorConsolePage />} />
        <Route path="/analytics" element={<WaitHeatmapPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      <BookingModal
        isOpen={bookingOpen}
        initialDoctorId={bookingDoctorId}
        onClose={() => setBookingOpen(false)}
      />
    </Layout>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ClinicProvider>
        <AppRoutes />
      </ClinicProvider>
    </BrowserRouter>
  );
}

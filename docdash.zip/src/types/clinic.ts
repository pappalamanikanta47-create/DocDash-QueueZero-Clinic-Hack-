export type Specialty =
  | 'General Medicine'
  | 'Pediatrics'
  | 'Orthopedics'
  | 'Cardiology';

export type ShiftType = 'Morning' | 'Evening';

export type DoctorStatus = 'In Consultation' | 'On Break' | 'Delayed';

export type TokenStatus =
  | 'waiting'
  | 'checked_in'
  | 'in_consultation'
  | 'completed'
  | 'skipped';

export type TokenPriority = 'normal' | 'emergency';

export interface Clinic {
  id: string;
  name: string;
  district: string;
  address: string;
  phone: string;
  openHours: string;
  latitude: number;
  longitude: number;
  imageUrl: string;
}

export interface Doctor {
  id: string;
  name: string;
  credentials: string;
  specialty: Specialty;
  clinicId: string;
  clinicName: string;
  consultationFee: number;
  baseAvgMinutes: number;
  dynamicAvgMinutes: number;
  recentDurations: number[];
  status: DoctorStatus;
  delayOffsetMinutes: number;
  shiftAvailability: ShiftType[];
}

export interface QueueToken {
  id: string;
  doctorId: string;
  clinicId: string;
  tokenNumber: number;
  queueRank: number;
  patientName: string;
  patientPhone: string;
  shift: ShiftType;
  status: TokenStatus;
  priority: TokenPriority;
  notes: string;
  prescriptionNotes: string | null;
  prescriptionFileName: string | null;
  prescriptionFileData: string | null;
  bookedAt: string;
  calledAt: string | null;
  completedAt: string | null;
  checkedInAt: string | null;
  checkInDistanceMeters: number | null;
}

export type SmsNotificationType =
  | 'booking_confirmed'
  | 'proximity_alert'
  | 'called'
  | 'delay_notice';

export interface SmsNotification {
  id: string;
  tokenId: string;
  tokenNumber: number;
  doctorId: string;
  doctorName: string;
  clinicName: string;
  patientPhone: string;
  message: string;
  sentAt: string;
  type: SmsNotificationType;
}

export interface HeatmapPoint {
  clinicId: string;
  specialty: Specialty;
  day: 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat' | 'Sun';
  slot: '08:00–11:00' | '11:00–14:00' | '16:00–19:00' | '19:00–21:00';
  avgWaitMinutes: number;
  patientVolume: number;
}

export interface ClinicAppState {
  clinics: Clinic[];
  doctors: Doctor[];
  tokens: QueueToken[];
  smsNotifications: SmsNotification[];
  heatmap: HeatmapPoint[];
  serverTime: string;
}

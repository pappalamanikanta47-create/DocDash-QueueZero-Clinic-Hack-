import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, CheckCircle2, ArrowRight } from 'lucide-react';
import { useClinic } from '../context/ClinicContext';
import type { QueueToken, ShiftType } from '../types/clinic';
import {
  calculateEstimatedWaitMinutes,
  formatTokenLabel,
  getActiveConsultationToken,
  getOrderedWaitingTokens,
} from '../utils/queueEstimator';

interface BookingModalProps {
  isOpen: boolean;
  initialDoctorId?: string | null;
  onClose: () => void;
}

export function BookingModal({
  isOpen,
  initialDoctorId,
  onClose,
}: BookingModalProps) {
  const { state, bookToken } = useClinic();
  const navigate = useNavigate();

  const [doctorId, setDoctorId] = useState<string>('');
  const [shift, setShift] = useState<ShiftType>('Morning');
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [confirmedToken, setConfirmedToken] = useState<QueueToken | null>(null);

  useEffect(() => {
    if (isOpen) {
      setDoctorId((prev) => initialDoctorId || prev || state?.doctors[0]?.id || '');
      setShift('Morning');
      setPatientName('');
      setPatientPhone('');
      setNotes('');
      setFormError(null);
      setConfirmedToken(null);
    }
    // Intentionally omit state?.doctors so background polling/WebSocket updates never wipe form input
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, initialDoctorId]);

  const selectedDoctor = useMemo(
    () => state?.doctors.find((d) => d.id === doctorId) ?? null,
    [state?.doctors, doctorId]
  );

  const queuePreview = useMemo(() => {
    if (!selectedDoctor || !state) return null;
    const doctorTokens = state.tokens.filter(
      (t) => t.doctorId === selectedDoctor.id
    );
    const maxToken = doctorTokens.reduce(
      (max, t) => Math.max(max, t.tokenNumber),
      0
    );
    const nextTokenNumber = maxToken + 1;
    const activeToken = getActiveConsultationToken(
      selectedDoctor.id,
      state.tokens
    );
    const waiting = getOrderedWaitingTokens(selectedDoctor.id, state.tokens);
    const patientsAhead = (activeToken ? 1 : 0) + waiting.length;
    const estWait = calculateEstimatedWaitMinutes(
      patientsAhead,
      selectedDoctor.dynamicAvgMinutes,
      selectedDoctor.delayOffsetMinutes,
      'waiting'
    );
    return {
      nextTokenNumber,
      activeTokenNumber: activeToken?.tokenNumber ?? null,
      patientsAhead,
      estWait,
    };
  }, [selectedDoctor, state]);

  if (!isOpen || !state) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);

    if (!doctorId) {
      setFormError('Please select a physician.');
      return;
    }
    if (!patientName.trim()) {
      setFormError('Please enter the patient full name.');
      return;
    }
    if (!patientPhone.trim()) {
      setFormError('Please enter a mobile number for SMS queue alerts.');
      return;
    }

    setSubmitting(true);
    try {
      const token = await bookToken({
        doctorId,
        patientName: patientName.trim(),
        patientPhone: patientPhone.trim(),
        shift,
        notes: notes.trim(),
      });
      setConfirmedToken(token);
    } catch (err) {
      setFormError(
        err instanceof Error ? err.message : 'Unable to book virtual token.'
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
    >
      <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2
              id="booking-modal-title"
              className="text-lg font-semibold text-slate-900"
            >
              {confirmedToken ? 'Virtual Token Confirmed' : 'Book Virtual Token'}
            </h2>
            <p className="text-xs text-slate-500">
              Sequential outpatient queue reservation
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close booking dialog"
            className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {confirmedToken && selectedDoctor ? (
          <div className="space-y-5 p-6">
            <div className="flex items-start gap-3 rounded-lg border border-emerald-200 bg-emerald-50 p-4">
              <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-700" />
              <div className="space-y-1">
                <p className="text-sm font-semibold text-emerald-950">
                  Token {formatTokenLabel(confirmedToken.tokenNumber)} issued for{' '}
                  {confirmedToken.patientName}
                </p>
                <p className="text-xs text-emerald-800">
                  {selectedDoctor.name} · {selectedDoctor.specialty} ·{' '}
                  {selectedDoctor.clinicName}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 border-y border-slate-200 py-4 text-center">
              <div>
                <p className="text-xs text-slate-500">Your Token</p>
                <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
                  {formatTokenLabel(confirmedToken.tokenNumber)}
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Shift</p>
                <p className="mt-1 text-base font-semibold text-slate-900">
                  {confirmedToken.shift}
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500">SMS Alerts To</p>
                <p className="mt-1 truncate font-mono text-xs font-medium text-slate-700">
                  {confirmedToken.patientPhone}
                </p>
              </div>
            </div>

            <p className="text-xs leading-relaxed text-slate-600">
              Your live wait countdown updates automatically as consultations
              progress. An SMS arrival alert triggers automatically when you are
              2 patients away.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0"
              >
                Done
              </button>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  navigate('/my-appointments');
                }}
                className="inline-flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-teal-800 whitespace-nowrap shrink-0"
              >
                <span>Track Live Queue</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 p-6">
            <div>
              <label
                htmlFor="booking-doctor"
                className="block text-sm font-medium text-slate-700"
              >
                Doctor &amp; Clinic Branch
              </label>
              <select
                id="booking-doctor"
                value={doctorId}
                onChange={(e) => setDoctorId(e.target.value)}
                className="mt-1.5 w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/20"
              >
                {state.doctors.map((doc) => (
                  <option key={doc.id} value={doc.id}>
                    {doc.name} — {doc.specialty} ({doc.clinicName}) · $
                    {doc.consultationFee}
                  </option>
                ))}
              </select>
            </div>

            {queuePreview && selectedDoctor && (
              <div className="grid grid-cols-3 gap-3 rounded-lg border border-slate-200 bg-slate-50 px-4 py-3">
                <div>
                  <p className="text-xs text-slate-500">Next Token</p>
                  <p className="font-mono text-lg font-bold text-teal-800 tabular-nums">
                    {formatTokenLabel(queuePreview.nextTokenNumber)}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Currently Serving</p>
                  <p className="font-mono text-lg font-semibold text-slate-900 tabular-nums">
                    {formatTokenLabel(queuePreview.activeTokenNumber)}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Est. Wait</p>
                  <p className="font-mono text-lg font-semibold text-slate-900 tabular-nums">
                    {queuePreview.estWait} mins
                  </p>
                </div>
              </div>
            )}

            <div>
              <span className="block text-sm font-medium text-slate-700">
                Outpatient Shift
              </span>
              <div className="mt-1.5 grid grid-cols-2 gap-2 rounded-lg bg-slate-100 p-1">
                {(['Morning', 'Evening'] as ShiftType[]).map((option) => (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setShift(option)}
                    className={`rounded-md px-3 py-2 text-sm font-medium transition-colors whitespace-nowrap ${
                      shift === option
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {option === 'Morning'
                      ? 'Morning (08:00–14:00)'
                      : 'Evening (16:00–21:00)'}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="booking-patient-name"
                  className="block text-sm font-medium text-slate-700"
                >
                  Patient Full Name
                </label>
                <input
                  id="booking-patient-name"
                  type="text"
                  required
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="e.g., Jordan Patel"
                  className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/20"
                />
              </div>

              <div>
                <label
                  htmlFor="booking-patient-phone"
                  className="block text-sm font-medium text-slate-700"
                >
                  Mobile Number (SMS Alerts)
                </label>
                <input
                  id="booking-patient-phone"
                  type="tel"
                  required
                  value={patientPhone}
                  onChange={(e) => setPatientPhone(e.target.value)}
                  placeholder="+1 (555) 204-8890"
                  className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/20"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="booking-notes"
                className="block text-sm font-medium text-slate-700"
              >
                Reason for Visit (Optional)
              </label>
              <input
                id="booking-notes"
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Brief symptom or follow-up note"
                className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/20"
              />
            </div>

            {formError && (
              <p
                role="alert"
                className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700"
              >
                {formError}
              </p>
            )}

            <div className="flex items-center justify-end gap-3 border-t border-slate-200 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="rounded-lg bg-teal-700 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-teal-800 disabled:opacity-60 whitespace-nowrap shrink-0"
              >
                {submitting ? 'Issuing Token…' : 'Confirm Token Booking'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

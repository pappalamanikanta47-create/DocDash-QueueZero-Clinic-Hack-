import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Building2, ArrowRight } from 'lucide-react';
import { useClinic } from '../context/ClinicContext';
import type { Doctor, Specialty } from '../types/clinic';
import {
  calculateEstimatedWaitMinutes,
  formatTokenLabel,
  getActiveConsultationToken,
  getOrderedWaitingTokens,
} from '../utils/queueEstimator';

const SPECIALTIES: Array<'All' | Specialty> = [
  'All',
  'General Medicine',
  'Pediatrics',
  'Orthopedics',
  'Cardiology',
];

function getStatusTextClass(status: Doctor['status']): string {
  if (status === 'In Consultation') return 'text-emerald-700';
  if (status === 'On Break') return 'text-amber-700';
  return 'text-red-700';
}

export function DoctorDirectoryPage({
  onBookDoctor,
}: {
  onBookDoctor: (doctorId: string) => void;
}) {
  const { state, loading, error } = useClinic();
  const [selectedClinicId, setSelectedClinicId] = useState<string>('all');
  const [selectedSpecialty, setSelectedSpecialty] = useState<'All' | Specialty>(
    'All'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [brokenImages, setBrokenImages] = useState<Record<string, boolean>>({});

  const filteredDoctors = useMemo(() => {
    if (!state) return [];
    const q = searchQuery.trim().toLowerCase();
    return state.doctors.filter((doc) => {
      if (selectedClinicId !== 'all' && doc.clinicId !== selectedClinicId) {
        return false;
      }
      if (
        selectedSpecialty !== 'All' &&
        doc.specialty !== selectedSpecialty
      ) {
        return false;
      }
      if (q) {
        const hay =
          `${doc.name} ${doc.specialty} ${doc.clinicName} ${doc.credentials}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [state, selectedClinicId, selectedSpecialty, searchQuery]);

  if (loading && !state) {
    return (
      <div className="space-y-6" aria-busy="true">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((n) => (
            <div
              key={n}
              className="h-56 animate-pulse rounded-xl border border-slate-200 bg-white"
            />
          ))}
        </div>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {[1, 2, 3, 4].map((n) => (
            <div
              key={n}
              className="h-44 animate-pulse rounded-xl border border-slate-200 bg-white"
            />
          ))}
        </div>
      </div>
    );
  }

  if (error && !state) {
    return (
      <div
        role="alert"
        className="rounded-xl border border-red-200 bg-red-50 p-6 text-sm text-red-800"
      >
        Unable to load clinic directory: {error}
      </div>
    );
  }

  if (!state) return null;

  return (
    <div className="space-y-8">
      {/* Clinic Branch Selector */}
      <section aria-labelledby="clinic-branches-heading" className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1
              id="clinic-branches-heading"
              className="text-2xl font-bold tracking-tight text-slate-900"
            >
              Outpatient Clinic Branches
            </h1>
            <p className="mt-1 text-sm text-slate-600">
              Select a healthcare branch to filter specialists and view live queue
              pacing.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setSelectedClinicId('all')}
            className={`rounded-lg border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              selectedClinicId === 'all'
                ? 'border-teal-700 bg-teal-700 text-white'
                : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
            }`}
          >
            All 4 Clinics
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {state.clinics.map((clinic) => {
            const isSelected = selectedClinicId === clinic.id;
            const clinicDocs = state.doctors.filter(
              (d) => d.clinicId === clinic.id
            );
            const activeWaitingCount = state.tokens.filter(
              (t) =>
                t.clinicId === clinic.id &&
                (t.status === 'waiting' || t.status === 'checked_in')
            ).length;

            return (
              <button
                key={clinic.id}
                type="button"
                onClick={() =>
                  setSelectedClinicId(isSelected ? 'all' : clinic.id)
                }
                aria-pressed={isSelected}
                className={`group overflow-hidden rounded-xl border text-left transition-colors ${
                  isSelected
                    ? 'border-teal-700 bg-teal-50/40 ring-2 ring-teal-700/20'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100">
                  {brokenImages[clinic.id] ? (
                    <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200 p-4 text-center text-slate-600">
                      <Building2 className="h-8 w-8 text-teal-700" />
                      <span className="mt-2 text-xs font-semibold">
                        {clinic.name}
                      </span>
                    </div>
                  ) : (
                    <img
                      src={clinic.imageUrl}
                      alt={`${clinic.name} building`}
                      referrerPolicy="no-referrer"
                      onError={() =>
                        setBrokenImages((prev) => ({
                          ...prev,
                          [clinic.id]: true,
                        }))
                      }
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                    />
                  )}
                </div>
                <div className="p-4">
                  <p className="text-sm font-semibold text-slate-900 truncate">
                    {clinic.name}
                  </p>
                  <p className="mt-0.5 text-xs text-slate-500">
                    {clinic.district} · <span className="tabular-nums whitespace-nowrap">{clinic.openHours}</span>
                  </p>
                  <p className="mt-2 text-xs font-medium text-slate-700 tabular-nums">
                    {clinicDocs.length} Doctors · {activeWaitingCount} Waiting
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Specialty Filters & Doctor Grid */}
      <section aria-labelledby="doctors-heading" className="space-y-4">
        <div className="flex flex-col gap-4 border-b border-slate-200 pb-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2
              id="doctors-heading"
              className="text-xl font-bold tracking-tight text-slate-900"
            >
              Specialists &amp; Live Queue Estimates
            </h2>
            <p className="mt-0.5 text-xs text-slate-500">
              Showing {filteredDoctors.length} of {state.doctors.length} physicians
              · Dynamic wait uses EWMA over last 5 visits
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="relative">
              <Search
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                aria-hidden="true"
              />
              <label htmlFor="doctor-search" className="sr-only">
                Search doctors or specialties
              </label>
              <input
                id="doctor-search"
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search doctor or clinic…"
                className="w-full rounded-lg border border-slate-300 bg-white py-2 pl-9 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/20 sm:w-56"
              />
            </div>

            <div
              role="tablist"
              aria-label="Filter by specialty"
              className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1"
            >
              {SPECIALTIES.map((specialty) => (
                <button
                  key={specialty}
                  type="button"
                  role="tab"
                  aria-selected={selectedSpecialty === specialty}
                  onClick={() => setSelectedSpecialty(specialty)}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    selectedSpecialty === specialty
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {specialty}
                </button>
              ))}
            </div>
          </div>
        </div>

        {filteredDoctors.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
            <p className="text-sm font-semibold text-slate-900">
              No doctors match these filters
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Reset your clinic or specialty filter to view all available
              physicians.
            </p>
            <button
              type="button"
              onClick={() => {
                setSelectedClinicId('all');
                setSelectedSpecialty('All');
                setSearchQuery('');
              }}
              className="mt-4 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {filteredDoctors.map((doc) => {
              const docTokens = state.tokens.filter(
                (t) => t.doctorId === doc.id
              );
              const activeToken = getActiveConsultationToken(
                doc.id,
                state.tokens
              );
              const waiting = getOrderedWaitingTokens(doc.id, state.tokens);
              const maxNum = docTokens.reduce(
                (max, t) => Math.max(max, t.tokenNumber),
                0
              );
              const nextTokenNumber = maxNum + 1;
              const patientsAhead = (activeToken ? 1 : 0) + waiting.length;
              const nextEstWait = calculateEstimatedWaitMinutes(
                patientsAhead,
                doc.dynamicAvgMinutes,
                doc.delayOffsetMinutes,
                'waiting'
              );

              return (
                <article
                  key={doc.id}
                  className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 transition-colors hover:border-slate-300"
                >
                  <div>
                    <div className="flex items-start justify-between gap-4">
                      <div className="min-w-0">
                        <h3 className="text-base font-bold text-slate-900 truncate">
                          {doc.name}
                        </h3>
                        <p className="mt-0.5 text-xs text-slate-600">
                          {doc.specialty} · {doc.credentials} · {doc.clinicName}
                        </p>
                      </div>
                      <span className="font-mono text-sm font-semibold text-slate-900 tabular-nums shrink-0">
                        ${doc.consultationFee}
                      </span>
                    </div>

                    <div className="mt-4 grid grid-cols-3 gap-4 border-y border-slate-100 py-3">
                      <div>
                        <p className="text-xs text-slate-500">Now Serving</p>
                        <p className="mt-0.5 font-mono text-base font-bold text-slate-900 tabular-nums">
                          {formatTokenLabel(activeToken?.tokenNumber ?? null)}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Next Token</p>
                        <p className="mt-0.5 font-mono text-base font-bold text-teal-800 tabular-nums">
                          {formatTokenLabel(nextTokenNumber)}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Est. Wait</p>
                        <p className="mt-0.5 font-mono text-base font-bold text-slate-900 tabular-nums">
                          {nextEstWait} mins
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                    <div className="text-xs text-slate-600">
                      <span
                        className={`font-semibold ${getStatusTextClass(doc.status)}`}
                      >
                        {doc.status}
                        {doc.delayOffsetMinutes > 0
                          ? ` (+${doc.delayOffsetMinutes}m)`
                          : ''}
                      </span>
                      <span aria-hidden="true"> · </span>
                      <span className="tabular-nums">
                        {doc.dynamicAvgMinutes} min avg · {waiting.length}{' '}
                        waiting
                      </span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <Link
                        to={`/queue-board?doctor=${doc.id}`}
                        className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 whitespace-nowrap"
                      >
                        <span>Queue</span>
                        <ArrowRight className="h-3.5 w-3.5" />
                      </Link>
                      <button
                        type="button"
                        onClick={() => onBookDoctor(doc.id)}
                        aria-label={`Book token with ${doc.name}`}
                        className="rounded-lg bg-teal-700 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-teal-800 whitespace-nowrap"
                      >
                        Book Token
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}

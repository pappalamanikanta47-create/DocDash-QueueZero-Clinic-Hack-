import React, { useMemo, useState } from 'react';
import { useClinic } from '../context/ClinicContext';
import type { HeatmapPoint, Specialty } from '../types/clinic';

const DAYS: HeatmapPoint['day'][] = [
  'Mon',
  'Tue',
  'Wed',
  'Thu',
  'Fri',
  'Sat',
  'Sun',
];

const SLOTS: HeatmapPoint['slot'][] = [
  '08:00–11:00',
  '11:00–14:00',
  '16:00–19:00',
  '19:00–21:00',
];

const SPECIALTIES: Specialty[] = [
  'Cardiology',
  'General Medicine',
  'Pediatrics',
  'Orthopedics',
];

function getHeatColor(waitMinutes: number): string {
  if (waitMinutes <= 20) {
    return 'bg-emerald-50 text-emerald-900 border-emerald-200';
  }
  if (waitMinutes <= 35) {
    return 'bg-teal-50 text-teal-900 border-teal-200';
  }
  if (waitMinutes <= 48) {
    return 'bg-amber-50 text-amber-950 border-amber-200';
  }
  return 'bg-red-50 text-red-900 border-red-200';
}

export function WaitHeatmapPage() {
  const { state } = useClinic();
  const [selectedClinicId, setSelectedClinicId] = useState<string>('clinic-metro');
  const [selectedSpecialty, setSelectedSpecialty] =
    useState<Specialty>('Cardiology');

  const filteredPoints = useMemo(() => {
    if (!state) return [];
    return state.heatmap.filter(
      (p) =>
        p.clinicId === selectedClinicId && p.specialty === selectedSpecialty
    );
  }, [state, selectedClinicId, selectedSpecialty]);

  const bestWindow = useMemo(() => {
    if (filteredPoints.length === 0) return null;
    return filteredPoints.reduce((best, curr) =>
      curr.avgWaitMinutes < best.avgWaitMinutes ? curr : best
    );
  }, [filteredPoints]);

  if (!state) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-8 text-sm text-slate-600">
        Loading wait-time analytics…
      </div>
    );
  }

  const clinic = state.clinics.find((c) => c.id === selectedClinicId);

  return (
    <div className="space-y-6">
      {/* Controls */}
      <section className="flex flex-col gap-4 rounded-xl border border-slate-200 bg-white p-5 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900">
            Clinic Wait Time Heatmap
          </h1>
          <p className="mt-0.5 text-xs text-slate-500">
            Historical average wait minutes by day of week and outpatient shift
            window
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <label htmlFor="heatmap-clinic" className="sr-only">
            Clinic branch
          </label>
          <select
            id="heatmap-clinic"
            value={selectedClinicId}
            onChange={(e) => setSelectedClinicId(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-900 focus:border-teal-700 focus:outline-none"
          >
            {state.clinics.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <div
            role="tablist"
            aria-label="Heatmap Specialty"
            className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1"
          >
            {SPECIALTIES.map((sp) => (
              <button
                key={sp}
                type="button"
                role="tab"
                aria-selected={selectedSpecialty === sp}
                onClick={() => setSelectedSpecialty(sp)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                  selectedSpecialty === sp
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {sp}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Recommended Low-Traffic Window */}
      {bestWindow && clinic && (
        <section className="grid grid-cols-1 gap-4 rounded-xl border border-slate-200 bg-white p-5 sm:grid-cols-3">
          <div>
            <p className="text-xs text-slate-500">Selected Clinic &amp; Dept</p>
            <p className="mt-1 text-sm font-bold text-slate-900">
              {clinic.name} · {selectedSpecialty}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Lowest-Traffic Window</p>
            <p className="mt-1 text-sm font-bold text-emerald-700">
              {bestWindow.day} · {bestWindow.slot}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Historical Average Wait</p>
            <p className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums">
              {bestWindow.avgWaitMinutes} mins ({bestWindow.patientVolume} avg
              patients)
            </p>
          </div>
        </section>
      )}

      {/* Heatmap Grid */}
      <section className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-sm font-bold text-slate-900">
            Weekly Outpatient Congestion Matrix
          </h2>
          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600">
            <span>Low (&le;20m)</span>
            <span>Moderate (21–35m)</span>
            <span>Busy (36–48m)</span>
            <span>Peak (&gt;48m)</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] border-separate border-spacing-2 text-left text-xs">
            <thead>
              <tr>
                <th className="w-28 py-2 font-semibold text-slate-600">
                  Consultation Slot
                </th>
                {DAYS.map((day) => (
                  <th
                    key={day}
                    className="py-2 text-center font-semibold text-slate-700"
                  >
                    {day}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {SLOTS.map((slot) => (
                <tr key={slot}>
                  <td className="py-2 pr-3 font-mono font-medium text-slate-700 tabular-nums whitespace-nowrap">
                    {slot}
                  </td>
                  {DAYS.map((day) => {
                    const cell = filteredPoints.find(
                      (p) => p.day === day && p.slot === slot
                    );
                    const wait = cell?.avgWaitMinutes ?? 0;
                    const vol = cell?.patientVolume ?? 0;
                    return (
                      <td key={day} className="p-0">
                        <div
                          className={`rounded-lg border px-2 py-3 text-center transition-colors ${getHeatColor(wait)}`}
                        >
                          <p className="font-mono text-sm font-bold tabular-nums">
                            {wait}m
                          </p>
                          <p className="mt-0.5 text-[11px] opacity-80 tabular-nums">
                            {vol} pts
                          </p>
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

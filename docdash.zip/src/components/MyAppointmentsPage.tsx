import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  MapPin,
  MessageSquare,
  FileText,
  Download,
  CheckCircle2,
  X,
} from 'lucide-react';
import { useClinic } from '../context/ClinicContext';
import {
  computeTokenMetrics,
  formatTokenLabel,
} from '../utils/queueEstimator';

export function MyAppointmentsPage({
  onOpenBooking,
}: {
  onOpenBooking: () => void;
}) {
  const {
    state,
    myTokenIds,
    trackTokenId,
    untrackTokenId,
    checkInWithCoordinates,
  } = useClinic();
  const [lookupTokenId, setLookupTokenId] = useState<string>('');
  const [checkInFeedback, setCheckInFeedback] = useState<
    Record<string, { ok: boolean; message: string }>
  >({});
  const [checkingInId, setCheckingInId] = useState<string | null>(null);

  const trackedTokens = useMemo(() => {
    if (!state) return [];
    return state.tokens.filter((t) => myTokenIds.includes(t.id));
  }, [state, myTokenIds]);

  const relevantSms = useMemo(() => {
    if (!state) return [];
    if (trackedTokens.length === 0) {
      return state.smsNotifications.slice(0, 8);
    }
    const trackedIds = new Set(trackedTokens.map((t) => t.id));
    const filtered = state.smsNotifications.filter((s) =>
      trackedIds.has(s.tokenId)
    );
    return filtered.length > 0 ? filtered : state.smsNotifications.slice(0, 8);
  }, [state, trackedTokens]);

  if (!state) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-8 text-sm text-slate-600">
        Loading appointments…
      </div>
    );
  }

  const availableTokensToTrack = state.tokens.filter(
    (t) => !myTokenIds.includes(t.id)
  );

  async function handleRealGeolocationCheckIn(tokenId: string) {
    setCheckingInId(tokenId);
    if (!navigator.geolocation) {
      setCheckInFeedback((prev) => ({
        ...prev,
        [tokenId]: {
          ok: false,
          message:
            'Browser geolocation is unavailable. Use Simulate Arrival below to test the 500m perimeter.',
        },
      }));
      setCheckingInId(null);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const res = await checkInWithCoordinates(
          tokenId,
          pos.coords.latitude,
          pos.coords.longitude
        );
        setCheckInFeedback((prev) => ({
          ...prev,
          [tokenId]: { ok: res.checkedIn, message: res.message },
        }));
        setCheckingInId(null);
      },
      () => {
        setCheckInFeedback((prev) => ({
          ...prev,
          [tokenId]: {
            ok: false,
            message:
              'Location permission denied or unavailable. Use Simulate Arrival to verify 500m check-in.',
          },
        }));
        setCheckingInId(null);
      },
      { enableHighAccuracy: true, timeout: 6000 }
    );
  }

  async function handleSimulateGeoCheckIn(
    tokenId: string,
    clinicLat: number,
    clinicLon: number,
    offsetLat: number
  ) {
    setCheckingInId(tokenId);
    const res = await checkInWithCoordinates(
      tokenId,
      clinicLat + offsetLat,
      clinicLon
    );
    setCheckInFeedback((prev) => ({
      ...prev,
      [tokenId]: { ok: res.checkedIn, message: res.message },
    }));
    setCheckingInId(null);
  }

  function handleDownloadSummary(
    patientName: string,
    tokenNumber: number,
    notes: string | null,
    fileName: string | null,
    fileData: string | null
  ) {
    if (fileData && fileName) {
      const link = document.createElement('a');
      link.href = fileData;
      link.download = fileName;
      link.click();
      return;
    }
    const content = `DocDash: QueueZero — Clinical Visit Summary\nToken: #${tokenNumber}\nPatient: ${patientName}\n\nSummary & Prescription Notes:\n${notes || 'No notes recorded.'}\n`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName || `Visit_Summary_Token_${tokenNumber}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
      {/* Main Column: Active & Completed Appointments */}
      <div className="space-y-6 xl:col-span-7">
        <div className="space-y-3 rounded-xl border border-slate-200 bg-white p-5">
          <div>
            <h1 className="text-lg font-bold text-slate-900">
              My Tracked Appointments
            </h1>
            <p className="text-xs text-slate-500">
              Live countdown, 500m geolocation check-in, and visit summaries
            </p>
          </div>

          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <label htmlFor="track-token-select" className="sr-only">
              Track an existing token
            </label>
            <select
              id="track-token-select"
              value={lookupTokenId}
              onChange={(e) => setLookupTokenId(e.target.value)}
              className="min-w-0 flex-1 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-800 focus:border-teal-700 focus:outline-none"
            >
              <option value="">Track an existing clinic token…</option>
              {availableTokensToTrack.map((t) => {
                const doc = state.doctors.find((d) => d.id === t.doctorId);
                return (
                  <option key={t.id} value={t.id}>
                    {formatTokenLabel(t.tokenNumber)} {t.patientName} —{' '}
                    {doc?.name ?? t.doctorId} ({t.status.replace('_', ' ')})
                  </option>
                );
              })}
            </select>
            <button
              type="button"
              disabled={!lookupTokenId}
              onClick={() => {
                if (lookupTokenId) {
                  trackTokenId(lookupTokenId);
                  setLookupTokenId('');
                }
              }}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              Track Token
            </button>
          </div>
        </div>

        {trackedTokens.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
            <h2 className="text-base font-bold text-slate-900">
              No active appointments tracked yet
            </h2>
            <p className="mx-auto mt-1 max-w-md text-sm text-slate-600">
              Book a new virtual token from the directory or select an existing
              clinic token above to watch live countdowns and SMS alerts.
            </p>
            <button
              type="button"
              onClick={onOpenBooking}
              className="mt-5 rounded-lg bg-teal-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-teal-800"
            >
              Book Virtual Token
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {trackedTokens.map((token) => {
              const doctor = state.doctors.find((d) => d.id === token.doctorId);
              const clinic = state.clinics.find((c) => c.id === token.clinicId);
              if (!doctor || !clinic) return null;

              const metrics = computeTokenMetrics(token, doctor, state.tokens);
              const feedback = checkInFeedback[token.id];

              return (
                <article
                  key={token.id}
                  data-testid={`appointment-card-${token.tokenNumber}`}
                  className="rounded-xl border border-slate-200 bg-white p-6 space-y-5"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                        <span>{doctor.specialty}</span>
                        <span aria-hidden="true">·</span>
                        <span>{clinic.name}</span>
                        <span aria-hidden="true">·</span>
                        <span>{token.shift} Shift</span>
                      </div>
                      <h2 className="mt-1 text-lg font-bold text-slate-900">
                        Token {formatTokenLabel(token.tokenNumber)} —{' '}
                        {token.patientName}
                      </h2>
                      <p className="text-sm text-slate-600">
                        {doctor.name} · Status:{' '}
                        <span className="font-semibold text-slate-900">
                          {doctor.status}
                        </span>
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => untrackTokenId(token.id)}
                      aria-label={`Remove Token #${token.tokenNumber} from My Appointments`}
                      className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>

                  {/* Amber Proximity Alert when 1 or 2 tokens away */}
                  {metrics.isProximityAlert && (
                    <div
                      role="status"
                      data-testid="proximity-amber-alert"
                      className="flex items-start gap-3 rounded-lg border border-amber-300 bg-amber-50 p-4 text-amber-950"
                    >
                      <AlertTriangle
                        className="mt-0.5 h-5 w-5 shrink-0 text-amber-600"
                        aria-hidden="true"
                      />
                      <div>
                        <p className="text-sm font-bold">
                          Please arrive at the clinic now!
                        </p>
                        <p className="mt-0.5 text-xs text-amber-900 tabular-nums">
                          {metrics.patientsAhead}{' '}
                          {metrics.patientsAhead === 1
                            ? 'Patient'
                            : 'Patients'}{' '}
                          Ahead — Est. Wait: {metrics.estimatedWaitMinutes} mins
                        </p>
                      </div>
                    </div>
                  )}

                  {token.status === 'in_consultation' && (
                    <div
                      role="status"
                      className="flex items-center gap-3 rounded-lg border border-emerald-300 bg-emerald-50 p-4 text-emerald-950"
                    >
                      <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-700" />
                      <p className="text-sm font-semibold">
                        Now Calling Token {formatTokenLabel(token.tokenNumber)} —
                        Proceed to {doctor.name}&apos;s consultation room.
                      </p>
                    </div>
                  )}

                  {/* Live Countdown Metrics */}
                  <div className="grid grid-cols-2 gap-4 border-y border-slate-100 py-4 sm:grid-cols-4">
                    <div>
                      <p className="text-xs text-slate-500">Now Serving</p>
                      <p className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
                        {formatTokenLabel(metrics.activeTokenNumber)}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Patients Ahead</p>
                      <p
                        data-testid={`patients-ahead-${token.tokenNumber}`}
                        className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums"
                      >
                        {token.status === 'completed' ||
                        token.status === 'skipped'
                          ? '0'
                          : metrics.patientsAhead}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Est. Wait</p>
                      <p
                        data-testid={`est-wait-${token.tokenNumber}`}
                        className="mt-1 font-mono text-2xl font-bold text-teal-800 tabular-nums"
                      >
                        {metrics.estimatedWaitMinutes} mins
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Queue State</p>
                      <p className="mt-1 text-sm font-semibold capitalize text-slate-900">
                        {token.status.replace('_', ' ')}
                      </p>
                    </div>
                  </div>

                  {/* Virtual Clinic Check-In (500m Geolocation) */}
                  {(token.status === 'waiting' ||
                    token.status === 'checked_in') && (
                    <div className="space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-2 text-xs text-slate-600">
                          <MapPin
                            className="h-4 w-4 text-teal-700"
                            aria-hidden="true"
                          />
                          {token.status === 'checked_in' ? (
                            <span className="font-semibold text-emerald-700">
                              Checked In via Geolocation (
                              {token.checkInDistanceMeters ?? 0}m from{' '}
                              {clinic.name})
                            </span>
                          ) : (
                            <span>
                              Auto-activates when within 500m of {clinic.name}
                            </span>
                          )}
                        </div>

                        {token.status === 'waiting' && (
                          <div className="flex flex-wrap items-center gap-2">
                            <button
                              type="button"
                              disabled={checkingInId === token.id}
                              onClick={() =>
                                handleRealGeolocationCheckIn(token.id)
                              }
                              className="rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap"
                            >
                              Check In via GPS
                            </button>
                            <button
                              type="button"
                              disabled={checkingInId === token.id}
                              onClick={() =>
                                handleSimulateGeoCheckIn(
                                  token.id,
                                  clinic.latitude,
                                  clinic.longitude,
                                  0.0016
                                )
                              }
                              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
                            >
                              Simulate Arrival (180m)
                            </button>
                            <button
                              type="button"
                              disabled={checkingInId === token.id}
                              onClick={() =>
                                handleSimulateGeoCheckIn(
                                  token.id,
                                  clinic.latitude,
                                  clinic.longitude,
                                  0.011
                                )
                              }
                              className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50 whitespace-nowrap"
                            >
                              Test 1.2km Away
                            </button>
                          </div>
                        )}
                      </div>

                      {feedback && (
                        <p
                          role="status"
                          className={`rounded-lg border px-3 py-2 text-xs ${
                            feedback.ok
                              ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                              : 'border-amber-200 bg-amber-50 text-amber-900'
                          }`}
                        >
                          {feedback.message}
                        </p>
                      )}
                    </div>
                  )}

                  {/* Digital Prescription & Visit Summary */}
                  {token.status === 'completed' && (
                    <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 space-y-2">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                          <FileText
                            className="h-4 w-4 text-teal-700"
                            aria-hidden="true"
                          />
                          <span>Digital Prescription &amp; Visit Summary</span>
                        </div>
                        {(token.prescriptionNotes ||
                          token.prescriptionFileName) && (
                          <button
                            type="button"
                            onClick={() =>
                              handleDownloadSummary(
                                token.patientName,
                                token.tokenNumber,
                                token.prescriptionNotes,
                                token.prescriptionFileName,
                                token.prescriptionFileData
                              )
                            }
                            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-100"
                          >
                            <Download className="h-3.5 w-3.5" />
                            <span>
                              {token.prescriptionFileName
                                ? `Download ${token.prescriptionFileName}`
                                : 'Download Summary'}
                            </span>
                          </button>
                        )}
                      </div>
                      <p className="text-xs leading-relaxed text-slate-700">
                        {token.prescriptionNotes ||
                          'Consultation completed. No additional prescription notes attached yet.'}
                      </p>
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        )}
      </div>

      {/* Right Column: Simulated SMS Gateway Feed */}
      <aside className="xl:col-span-5">
        <div className="rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
            <div className="flex items-center gap-2">
              <MessageSquare
                className="h-4 w-4 text-teal-700"
                aria-hidden="true"
              />
              <h2 className="text-base font-bold text-slate-900">
                SMS Notification Simulator
              </h2>
            </div>
            <span className="font-mono text-xs text-slate-500 tabular-nums">
              {relevantSms.length} dispatches
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {relevantSms.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500">
                SMS alerts will appear here when you book a token or reach 2
                patients away.
              </div>
            ) : (
              relevantSms.map((sms) => (
                <div
                  key={sms.id}
                  data-testid={`sms-item-${sms.type}`}
                  className={`p-4 ${
                    sms.type === 'proximity_alert' ? 'bg-amber-50/50' : ''
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-semibold text-slate-900">
                      Token {formatTokenLabel(sms.tokenNumber)} ·{' '}
                      {sms.type === 'proximity_alert'
                        ? '2 Tokens Away Alert'
                        : sms.type === 'called'
                          ? 'Now Calling'
                          : sms.type === 'delay_notice'
                            ? 'Delay Notice'
                            : 'Booking Confirmed'}
                    </span>
                    <span className="font-mono text-slate-500 tabular-nums">
                      {new Date(sms.sentAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-slate-600">
                    To: <span className="font-mono">{sms.patientPhone}</span>
                  </p>
                  <p className="mt-2 text-sm leading-relaxed text-slate-800">
                    {sms.message}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      </aside>
    </div>
  );
}

import React, { useMemo, useState } from 'react';
import {
  Play,
  CheckCircle2,
  Clock,
  UserX,
  RotateCcw,
  AlertOctagon,
  Upload,
} from 'lucide-react';
import { useClinic } from '../context/ClinicContext';
import type { DoctorStatus, ShiftType } from '../types/clinic';
import {
  computeTokenMetrics,
  formatTokenLabel,
  getActiveConsultationToken,
  getOrderedWaitingTokens,
} from '../utils/queueEstimator';

export function DoctorConsolePage() {
  const {
    state,
    callNextPatient,
    markCurrentCompleted,
    addDoctorDelay,
    updateDoctorStatus,
    skipAbsentToken,
    requeueSkippedToken,
    escalateEmergency,
    resetDemoData,
  } = useClinic();

  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('doc-mehta');
  const [durationMinutes, setDurationMinutes] = useState<number>(12);
  const [rxNotes, setRxNotes] = useState<string>('');
  const [rxFileName, setRxFileName] = useState<string | null>(null);
  const [rxFileData, setRxFileData] = useState<string | null>(null);
  const [showCompletePanel, setShowCompletePanel] = useState(false);

  // Emergency escalation form state
  const [emergName, setEmergName] = useState('');
  const [emergPhone, setEmergPhone] = useState('');
  const [emergNotes, setEmergNotes] = useState('');
  const [emergShift, setEmergShift] = useState<ShiftType>('Morning');
  const [actionError, setActionError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const doctor = useMemo(() => {
    if (!state) return null;
    return (
      state.doctors.find((d) => d.id === selectedDoctorId) ??
      state.doctors[0] ??
      null
    );
  }, [state, selectedDoctorId]);

  if (!state || !doctor) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-8 text-sm text-slate-600">
        Loading Doctor Console…
      </div>
    );
  }

  const activeToken = getActiveConsultationToken(doctor.id, state.tokens);
  const waitingTokens = getOrderedWaitingTokens(doctor.id, state.tokens);
  const skippedTokens = state.tokens.filter(
    (t) => t.doctorId === doctor.id && t.status === 'skipped'
  );

  async function runAction(fn: () => Promise<void>) {
    setActionError(null);
    setBusy(true);
    try {
      await fn();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Operation failed');
    } finally {
      setBusy(false);
    }
  }

  function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      setActionError('Prescription attachment must be under 2 MB.');
      return;
    }
    setRxFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setRxFileData(reader.result);
      }
    };
    reader.readAsDataURL(file);
  }

  async function handleCompleteSubmit(e: React.FormEvent) {
    e.preventDefault();
    await runAction(async () => {
      await markCurrentCompleted({
        doctorId: doctor!.id,
        durationMinutes,
        prescriptionNotes: rxNotes.trim() || undefined,
        prescriptionFileName: rxFileName,
        prescriptionFileData: rxFileData,
      });
      setRxNotes('');
      setRxFileName(null);
      setRxFileData(null);
      setShowCompletePanel(false);
    });
  }

  async function handleEmergencySubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!emergName.trim()) {
      setActionError('Enter emergency patient name before escalating.');
      return;
    }
    await runAction(async () => {
      await escalateEmergency({
        doctorId: doctor!.id,
        patientName: emergName.trim(),
        patientPhone: emergPhone.trim() || 'Triage Desk',
        shift: emergShift,
        notes: emergNotes.trim() || 'Urgent triage escalation',
      });
      setEmergName('');
      setEmergPhone('');
      setEmergNotes('');
    });
  }

  return (
    <div className="space-y-6">
      {/* Top Physician Selector & Primary Action Toolbar */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
          <div className="flex flex-wrap items-center gap-3 min-w-0">
            <label
              htmlFor="console-doctor-select"
              className="text-sm font-semibold text-slate-800 whitespace-nowrap"
            >
              Physician Console:
            </label>
            <select
              id="console-doctor-select"
              value={doctor.id}
              onChange={(e) => {
                setSelectedDoctorId(e.target.value);
                setShowCompletePanel(false);
              }}
              className="min-w-0 max-w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/20 sm:max-w-sm"
            >
              {state.doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.specialty} · {d.clinicName})
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                runAction(() => callNextPatient(doctor.id, durationMinutes))
              }
              className="inline-flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-teal-800 disabled:opacity-50 whitespace-nowrap"
            >
              <Play className="h-4 w-4" aria-hidden="true" />
              <span>Call Next Patient</span>
            </button>

            <button
              type="button"
              disabled={busy || !activeToken}
              onClick={() => setShowCompletePanel((v) => !v)}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-800 transition-colors hover:bg-slate-50 disabled:opacity-50 whitespace-nowrap"
            >
              <CheckCircle2 className="h-4 w-4 text-emerald-700" aria-hidden="true" />
              <span>Mark Completed</span>
            </button>

            <button
              type="button"
              disabled={busy}
              onClick={() => runAction(() => addDoctorDelay(doctor.id, 10))}
              className="inline-flex items-center gap-2 rounded-lg border border-amber-300 bg-amber-50 px-4 py-2.5 text-sm font-semibold text-amber-900 transition-colors hover:bg-amber-100 disabled:opacity-50 whitespace-nowrap"
            >
              <Clock className="h-4 w-4 text-amber-700" aria-hidden="true" />
              <span>Delay 10 mins</span>
            </button>
          </div>
        </div>

        {/* Status & EWMA Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-slate-100 pt-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-slate-500">Status:</span>
            <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
              {(
                ['In Consultation', 'On Break', 'Delayed'] as DoctorStatus[]
              ).map((st) => (
                <button
                  key={st}
                  type="button"
                  disabled={busy}
                  onClick={() =>
                    runAction(() =>
                      updateDoctorStatus(
                        doctor.id,
                        st,
                        st === 'In Consultation'
                      )
                    )
                  }
                  className={`rounded-md px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                    doctor.status === st
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
            {doctor.delayOffsetMinutes > 0 && (
              <span className="font-mono text-xs font-semibold text-amber-700 tabular-nums">
                +{doctor.delayOffsetMinutes}m offset
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
            <label htmlFor="ewma-duration-input" className="font-medium">
              Visit Duration (min):
            </label>
            <input
              id="ewma-duration-input"
              type="number"
              min={5}
              max={30}
              value={durationMinutes}
              onChange={(e) =>
                setDurationMinutes(
                  Math.min(30, Math.max(5, Number(e.target.value) || 12))
                )
              }
              className="w-16 rounded-md border border-slate-300 px-2 py-1 font-mono text-xs text-slate-900 tabular-nums"
            />
            <span className="font-mono tabular-nums text-slate-700">
              EWMA Pace: <strong>{doctor.dynamicAvgMinutes}m</strong>
            </span>
            <button
              type="button"
              disabled={busy}
              onClick={() => runAction(() => resetDemoData())}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50 whitespace-nowrap"
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Reset Demo</span>
            </button>
          </div>
        </div>

        {actionError && (
          <p
            role="alert"
            className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700"
          >
            {actionError}
          </p>
        )}
      </section>

      {/* Mark Completed + Digital Prescription Form */}
      {showCompletePanel && activeToken && (
        <form
          onSubmit={handleCompleteSubmit}
          className="rounded-xl border border-teal-200 bg-white p-5 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900">
              Complete Token {formatTokenLabel(activeToken.tokenNumber)} —{' '}
              {activeToken.patientName}
            </h2>
            <button
              type="button"
              onClick={() => setShowCompletePanel(false)}
              className="text-xs font-medium text-slate-500 hover:text-slate-800"
            >
              Cancel
            </button>
          </div>

          <div>
            <label
              htmlFor="rx-notes"
              className="block text-xs font-semibold text-slate-700"
            >
              Digital Prescription &amp; Clinical Summary Notes
            </label>
            <textarea
              id="rx-notes"
              rows={3}
              value={rxNotes}
              onChange={(e) => setRxNotes(e.target.value)}
              placeholder="e.g., BP 124/78 mmHg. Continue Atorvastatin 20mg nightly. Follow up in 4 weeks."
              className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4">
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100">
              <Upload className="h-3.5 w-3.5" aria-hidden="true" />
              <span>
                {rxFileName
                  ? `Attached: ${rxFileName}`
                  : 'Attach Summary PDF / File'}
              </span>
              <input
                type="file"
                accept=".pdf,.txt,.png,.jpg,.jpeg"
                onChange={handleFileUpload}
                className="sr-only"
              />
            </label>

            <button
              type="submit"
              disabled={busy}
              className="rounded-lg bg-emerald-700 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-800 disabled:opacity-50"
            >
              Save Summary &amp; Mark Completed
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
        {/* Left: Active Consultation, Waiting Queue, Skipped Holding & Emergency Escalation */}
        <div className="space-y-6 xl:col-span-7">
          {/* Active Patient Card */}
          <section className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="text-xs font-medium text-slate-500">
                  Active Consultation Room
                </p>
                {activeToken ? (
                  <>
                    <h2 className="mt-1 text-xl font-bold text-slate-900 tabular-nums">
                      Token {formatTokenLabel(activeToken.tokenNumber)} —{' '}
                      {activeToken.patientName}
                    </h2>
                    <p className="mt-1 text-xs text-slate-600">
                      {activeToken.shift} Shift · Phone:{' '}
                      <span className="font-mono">{activeToken.patientPhone}</span>
                    </p>
                    {activeToken.notes && (
                      <p className="mt-2 text-sm text-slate-700">
                        Reason: {activeToken.notes}
                      </p>
                    )}
                  </>
                ) : (
                  <p className="mt-1 text-base font-semibold text-slate-700">
                    No active consultation — click &ldquo;Call Next Patient&rdquo;
                    to begin.
                  </p>
                )}
              </div>

              {activeToken && (
                <button
                  type="button"
                  disabled={busy}
                  onClick={() =>
                    runAction(() => skipAbsentToken(activeToken.id))
                  }
                  className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-semibold text-red-700 hover:bg-red-100 whitespace-nowrap"
                >
                  <UserX className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Patient Absent — Skip Token</span>
                </button>
              )}
            </div>
          </section>

          {/* Waiting Queue Table */}
          <section className="rounded-xl border border-slate-200 bg-white">
            <div className="border-b border-slate-200 px-5 py-4">
              <h2 className="text-base font-bold text-slate-900">
                Upcoming Queue ({waitingTokens.length})
              </h2>
            </div>

            {waitingTokens.length === 0 ? (
              <div className="p-6 text-center text-sm text-slate-500">
                Waiting queue is clear for {doctor.name}.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-left text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                      <th className="px-5 py-2.5">Token</th>
                      <th className="px-5 py-2.5">Patient</th>
                      <th className="px-5 py-2.5">Status</th>
                      <th className="px-5 py-2.5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {waitingTokens.map((tok) => (
                      <tr key={tok.id} className="hover:bg-slate-50">
                        <td className="px-5 py-3 font-mono font-bold text-slate-900 tabular-nums">
                          {formatTokenLabel(tok.tokenNumber)}
                          {tok.priority === 'emergency' && (
                            <span className="ml-2 font-sans text-xs font-semibold text-red-700">
                              Urgent
                            </span>
                          )}
                        </td>
                        <td className="px-5 py-3">
                          <p className="font-medium text-slate-900">
                            {tok.patientName}
                          </p>
                          <p className="text-xs text-slate-500">
                            {tok.notes || `${tok.shift} shift`}
                          </p>
                        </td>
                        <td className="px-5 py-3 text-xs capitalize text-slate-600">
                          {tok.status.replace('_', ' ')}
                        </td>
                        <td className="px-5 py-3 text-right">
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() =>
                              runAction(() => skipAbsentToken(tok.id))
                            }
                            aria-label={`Skip Token #${tok.tokenNumber}`}
                            className="rounded-md border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100"
                          >
                            Skip Absent
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>

          {/* Holding Queue (Skipped Tokens) */}
          {skippedTokens.length > 0 && (
            <section className="rounded-xl border border-slate-200 bg-white p-5">
              <h3 className="text-sm font-bold text-slate-900">
                Holding Queue — Absent / Skipped ({skippedTokens.length})
              </h3>
              <div className="mt-3 divide-y divide-slate-100">
                {skippedTokens.map((tok) => (
                  <div
                    key={tok.id}
                    className="flex items-center justify-between py-2.5 text-sm"
                  >
                    <div>
                      <span className="font-mono font-semibold text-slate-900 tabular-nums">
                        {formatTokenLabel(tok.tokenNumber)}
                      </span>{' '}
                      <span className="text-slate-700">{tok.patientName}</span>
                    </div>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() =>
                        runAction(() => requeueSkippedToken(tok.id))
                      }
                      className="rounded-md border border-slate-300 px-3 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50"
                    >
                      Re-queue
                    </button>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Emergency Escalation Queue Insertion */}
          <section className="rounded-xl border border-red-200 bg-white p-5">
            <div className="flex items-center gap-2">
              <AlertOctagon
                className="h-4 w-4 text-red-600"
                aria-hidden="true"
              />
              <h3 className="text-sm font-bold text-slate-900">
                Emergency Escalation Triage
              </h3>
            </div>
            <p className="mt-1 text-xs text-slate-600">
              Insert an urgent trauma or critical patient ahead in{' '}
              {doctor.name}&apos;s queue with automated downstream wait
              recalculation.
            </p>
            <form
              onSubmit={handleEmergencySubmit}
              className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-4"
            >
              <div className="sm:col-span-2">
                <label htmlFor="emerg-name" className="sr-only">
                  Emergency patient name
                </label>
                <input
                  id="emerg-name"
                  type="text"
                  value={emergName}
                  onChange={(e) => setEmergName(e.target.value)}
                  placeholder="Critical patient name"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:border-red-600 focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="emerg-notes" className="sr-only">
                  Triage reason
                </label>
                <input
                  id="emerg-notes"
                  type="text"
                  value={emergNotes}
                  onChange={(e) => setEmergNotes(e.target.value)}
                  placeholder="Triage note"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-900 focus:border-red-600 focus:outline-none"
                />
              </div>
              <button
                type="submit"
                disabled={busy}
                className="rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white hover:bg-red-700 disabled:opacity-50 whitespace-nowrap"
              >
                Escalate Priority
              </button>
            </form>
          </section>
        </div>

        {/* Right: Live Patient View Mirror for Instant Split-Screen Verification */}
        <aside className="xl:col-span-5">
          <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-slate-900">
                Live Patient Wait Mirror
              </h2>
              <p className="text-xs text-slate-500">
                Synchronized real-time view seen by patients for {doctor.name}
              </p>
            </div>

            <div className="rounded-lg bg-slate-900 p-4 text-white">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Currently in Clinic</span>
                <span>{doctor.status}</span>
              </div>
              <p className="mt-1 font-mono text-3xl font-bold text-emerald-400 tabular-nums">
                {formatTokenLabel(activeToken?.tokenNumber ?? null)}
              </p>
              <p className="mt-0.5 text-xs text-slate-300">
                {activeToken
                  ? activeToken.patientName
                  : 'Waiting for next call'}
              </p>
            </div>

            <div className="space-y-3">
              {waitingTokens.length === 0 ? (
                <p className="py-4 text-center text-xs text-slate-500">
                  No waiting tokens to preview.
                </p>
              ) : (
                waitingTokens.map((tok) => {
                  const metrics = computeTokenMetrics(tok, doctor, state.tokens);
                  return (
                    <div
                      key={tok.id}
                      data-testid={`mirror-token-${tok.tokenNumber}`}
                      className={`rounded-lg border p-3.5 ${
                        metrics.isProximityAlert
                          ? 'border-amber-300 bg-amber-50'
                          : 'border-slate-200 bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                          Token {formatTokenLabel(tok.tokenNumber)} ·{' '}
                          {tok.patientName}
                        </span>
                        <span className="font-mono text-sm font-bold text-teal-800 tabular-nums">
                          {metrics.estimatedWaitMinutes} mins
                        </span>
                      </div>
                      <p className="mt-1 text-xs text-slate-700 tabular-nums">
                        {metrics.patientsAhead}{' '}
                        {metrics.patientsAhead === 1 ? 'Patient' : 'Patients'}{' '}
                        Ahead
                        {metrics.isProximityAlert
                          ? ' — Please arrive at the clinic now!'
                          : ''}
                      </p>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

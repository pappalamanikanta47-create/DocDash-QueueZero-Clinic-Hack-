import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  Stethoscope,
  Monitor,
  Ticket,
  ClipboardList,
  BarChart3,
  Menu,
  X,
  Plus,
} from 'lucide-react';
import { useClinic } from '../context/ClinicContext';

interface LayoutProps {
  children: React.ReactNode;
  onOpenBooking: (doctorId?: string) => void;
}

const NAV_ITEMS = [
  { to: '/', label: 'Doctor Directory', icon: Stethoscope },
  { to: '/queue-board', label: 'Live Queue Board', icon: Monitor },
  { to: '/my-appointments', label: 'My Appointments', icon: Ticket },
  { to: '/doctor-console', label: 'Doctor Console', icon: ClipboardList },
  { to: '/analytics', label: 'Wait Heatmap', icon: BarChart3 },
];

const ROUTE_TITLES: Record<string, { section: string; description: string }> = {
  '/': {
    section: 'Doctor Directory',
    description: 'Browse clinics, filter specialties, and book virtual tokens',
  },
  '/queue-board': {
    section: 'Live Queue Board',
    description: 'Real-time waiting room token display and physician status',
  },
  '/my-appointments': {
    section: 'My Appointments & SMS',
    description: 'Live wait countdown, 500m check-in, and arrival SMS alerts',
  },
  '/doctor-console': {
    section: 'Doctor Console',
    description: 'Advance patient tokens, manage pacing, and attach summaries',
  },
  '/analytics': {
    section: 'Wait Time Heatmap',
    description: 'Historical outpatient wait patterns across the week',
  },
};

export function Layout({ children, onOpenBooking }: LayoutProps) {
  const { myTokenIds, state, wsConnected } = useClinic();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const routeMeta = ROUTE_TITLES[location.pathname] ?? ROUTE_TITLES['/'];

  const activeAlertCount =
    state?.tokens.filter(
      (t) =>
        myTokenIds.includes(t.id) &&
        (t.status === 'waiting' || t.status === 'checked_in')
    ).length ?? 0;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 lg:flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:shrink-0 lg:flex-col lg:border-r lg:border-slate-200 lg:bg-white">
        <div className="flex h-16 items-center border-b border-slate-200 px-6">
          <NavLink
            to="/"
            className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap"
          >
            DocDash: QueueZero
          </NavLink>
        </div>

        <nav
          aria-label="Primary Navigation"
          className="flex-1 space-y-1 px-3 py-5"
        >
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) =>
                  `flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-teal-50 text-teal-800'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`
                }
              >
                <span className="flex items-center gap-3">
                  <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>{item.label}</span>
                </span>
                {item.to === '/my-appointments' && activeAlertCount > 0 && (
                  <span className="font-mono text-xs font-semibold text-teal-700 tabular-nums">
                    {activeAlertCount}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        <div className="border-t border-slate-200 px-5 py-4 text-xs text-slate-500">
          <p className="font-medium text-slate-700">Outpatient Network</p>
          <p className="mt-0.5">
            {state ? `${state.clinics.length} Clinics · ${state.doctors.length} Doctors` : 'Connecting…'}
          </p>
          <p className="mt-1 text-slate-500">
            {wsConnected ? 'Live sync active' : 'Polling sync active'}
          </p>
        </div>
      </aside>

      {/* Mobile Header + Drawer */}
      <div className="flex flex-1 flex-col min-w-0">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-4 border-b border-slate-200 bg-white px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen((v) => !v)}
              aria-label="Toggle navigation menu"
              aria-expanded={mobileMenuOpen}
              className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 lg:hidden"
            >
              {mobileMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </button>
            <div className="min-w-0">
              <div className="flex items-center gap-2 text-sm">
                <span className="font-semibold text-slate-900 truncate">
                  {routeMeta.section}
                </span>
                <span
                  aria-hidden="true"
                  className="hidden sm:inline text-slate-300"
                >
                  /
                </span>
                <span className="hidden sm:inline text-xs text-slate-500 truncate">
                  {routeMeta.description}
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onOpenBooking()}
            className="inline-flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-teal-800 whitespace-nowrap shrink-0"
          >
            <Plus className="h-4 w-4" aria-hidden="true" />
            <span>Book Token</span>
          </button>
        </header>

        {mobileMenuOpen && (
          <nav
            aria-label="Mobile Navigation"
            className="border-b border-slate-200 bg-white px-4 py-3 lg:hidden"
          >
            <div className="flex flex-col gap-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    end={item.to === '/'}
                    onClick={() => setMobileMenuOpen(false)}
                    className={({ isActive }) =>
                      `flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium ${
                        isActive
                          ? 'bg-teal-50 text-teal-800'
                          : 'text-slate-700 hover:bg-slate-100'
                      }`
                    }
                  >
                    <span className="flex items-center gap-3">
                      <Icon className="h-4 w-4" aria-hidden="true" />
                      <span>{item.label}</span>
                    </span>
                    {item.to === '/my-appointments' && activeAlertCount > 0 && (
                      <span className="font-mono text-xs font-semibold text-teal-700 tabular-nums">
                        {activeAlertCount}
                      </span>
                    )}
                  </NavLink>
                );
              })}
            </div>
          </nav>
        )}

        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl">{children}</div>
        </main>
      </div>
    </div>
  );
}

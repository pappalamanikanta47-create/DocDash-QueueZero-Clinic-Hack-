import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useClinic } from '../context/ClinicContext';
import {
  computeTokenMetrics,
  formatTokenLabel,
  getActiveConsultationToken,
  getNextInLineToken,
  getOrderedWaitingTokens,
} from '../utils/queueEstimator';

export function LiveQueueBoardPage({
  onBookDoctor,
}: {
  onBookDoctor: (doctorId: string) => void;
}) {
  const { state, trackTokenId } = useClinic();
  const [searchParams, setSearchParams] = useSearchParams();
  const doctorParam = searchParams.get('doctor');
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>(
    doctorParam || 'doc-mehta'
  );

  useEffect(() => {
    if (doctorParam && state?.doctors.some((d) => d.id === doctorParam)) {
      setSelectedDoctorId(doctorParam);
    }
  }, [doctorParam, state?.doctors]);

  const doctor = useMemo(() => {
    if (!state) return null;
    return (
      state.doctors.find((d) => d.id === selectedDoctorId) ??
      state.doctors[0] ??
      null
    );
  }, [state, selectedDoctorId]);

  if (!state || !doctor) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-8 text-sm text-slate-600">
        Loading waiting room queue board…
      </div>
    );
  }

  const activeToken = getActiveConsultationToken(doctor.id, state.tokens);
  const nextToken = getNextInLineToken(doctor.id, state.tokens);
  const waitingTokens = getOrderedWaitingTokens(doctor.id, state.tokens);
  const completedTokens = state.tokens
    .filter((t) => t.doctorId === doctor.id && t.status === 'completed')
    .slice(-5)
    .reverse();

  return (
    <div className="space-y-6">
      {/* Selector Bar */}
      <div className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <label
            htmlFor="queue-board-doctor"
            className="text-sm font-medium text-slate-700"
          >
            Clinic &amp; Specialist Board:
          </label>
          <select
            id="queue-board-doctor"
            value={doctor.id}
            onChange={(e) => {
              setSelectedDoctorId(e.target.value);
              setSearchParams({ doctor: e.target.value });
            }}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-900 focus:border-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-700/20"
          >
            {state.doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} · {d.specialty} ({d.clinicName})
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={() => onBookDoctor(doctor.id)}
          className="rounded-lg bg-teal-700 px-4 py-2 text-xs font-semibold text-white hover:bg-teal-800 whitespace-nowrap shrink-0"
        >
          Book Next Token for {doctor.name}
        </button>
      </div>

      {/* Waiting Room Hardware Display Board */}
      <section
        aria-label="Waiting Room Token Board"
        className="rounded-xl bg-slate-900 p-6 text-white sm:p-8"
      >
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div>
            <p className="text-xs font-medium text-slate-400">
              {doctor.clinicName} · {doctor.specialty}
            </p>
            <h1 className="mt-1 text-2xl font-bold tracking-tight text-white">
              {doctor.name}
            </h1>
          </div>
          <div className="text-right">
            <p className="text-xs text-slate-400">Physician Status</p>
            <p
              className={`mt-1 text-base font-semibold ${
                doctor.status === 'In Consultation'
                  ? 'text-emerald-400'
                  : doctor.status === 'On Break'
                    ? 'text-amber-400'
                    : 'text-red-400'
              }`}
            >
              {doctor.status}
              {doctor.delayOffsetMinutes > 0
                ? ` (+${doctor.delayOffsetMinutes}m offset)`
                : ''}
            </p>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-3">
          <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-5">
            <p className="text-xs font-medium text-slate-400">
              Currently Serving
            </p>
            <p
              data-testid="board-active-token"
              className="mt-2 font-mono text-5xl font-bold tracking-tight text-emerald-400 tabular-nums"
            >
              {formatTokenLabel(activeToken?.tokenNumber ?? null)}
            </p>
            <p className="mt-2 text-sm text-slate-300 truncate">
              {activeToken ? activeToken.patientName : 'Waiting for doctor'}
            </p>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-5">
            <p className="text-xs font-medium text-slate-400">Next in Line</p>
            <p
              data-testid="board-next-token"
              className="mt-2 font-mono text-5xl font-bold tracking-tight text-amber-300 tabular-nums"
            >
              {formatTokenLabel(nextToken?.tokenNumber ?? null)}
            </p>
            <p className="mt-2 text-sm text-slate-300 truncate">
              {nextToken
                ? `${nextToken.patientName}${nextToken.priority === 'emergency' ? ' (Urgent)' : ''}`
                : 'Queue clear'}
            </p>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-5">
            <p className="text-xs font-medium text-slate-400">
              Dynamic Consultation Pace
            </p>
            <p className="mt-2 font-mono text-5xl font-bold tracking-tight text-white tabular-nums">
              {doctor.dynamicAvgMinutes}
              <span className="ml-1.5 text-xl font-normal text-slate-400">
                min
              </span>
            </p>
            <p className="mt-2 text-xs text-slate-400 tabular-nums">
              EWMA of last {doctor.recentDurations.length} visits ·{' '}
              {waitingTokens.length} waiting
            </p>
          </div>
        </div>
      </section>

      {/* Upcoming Queue Table */}
      <section className="rounded-xl border border-slate-200 bg-white">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Live Waiting Queue ({waitingTokens.length})
            </h2>
            <p className="text-xs text-slate-500">
              Real-time sequence ordered by triage priority and token number
            </p>
          </div>
          <Link
            to="/my-appointments"
            className="text-xs font-semibold text-teal-700 hover:text-teal-800"
          >
            Go to My Appointments
          </Link>
        </div>

        {waitingTokens.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No patients currently waiting for {doctor.name}.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="px-6 py-3">Token</th>
                  <th className="px-6 py-3">Patient</th>
                  <th className="px-6 py-3">Shift</th>
                  <th className="px-6 py-3">Check-In</th>
                  <th className="px-6 py-3 text-right">Patients Ahead</th>
                  <th className="px-6 py-3 text-right">Est. Wait</th>
                  <th className="px-6 py-3 text-right">Track</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {waitingTokens.map((tok) => {
                  const metrics = computeTokenMetrics(tok, doctor, state.tokens);
                  return (
                    <tr
                      key={tok.id}
                      className="transition-colors hover:bg-slate-50"
                    >
                      <td className="px-6 py-3 font-mono font-bold text-slate-900 tabular-nums">
                        {formatTokenLabel(tok.tokenNumber)}
                        {tok.priority === 'emergency' && (
                          <span className="ml-2 font-sans text-xs font-semibold text-red-700">
                            Urgent
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-3 font-medium text-slate-900">
                        {tok.patientName}
                      </td>
                      <td className="px-6 py-3 text-slate-600">{tok.shift}</td>
                      <td className="px-6 py-3 text-xs">
                        {tok.status === 'checked_in' ? (
                          <span className="font-medium text-emerald-700">
                            Checked in ({tok.checkInDistanceMeters ?? 0}m)
                          </span>
                        ) : (
                          <span className="text-slate-500">Remote</span>
                        )}
                      </td>
                      <td className="px-6 py-3 text-right font-mono tabular-nums text-slate-700">
                        {metrics.patientsAhead}
                      </td>
                      <td className="px-6 py-3 text-right font-mono font-semibold tabular-nums text-slate-900">
                        {metrics.estimatedWaitMinutes} mins
                      </td>
                      <td className="px-6 py-3 text-right">
                        <Link
                          to="/my-appointments"
                          onClick={() => trackTokenId(tok.id)}
                          className="text-xs font-semibold text-teal-700 hover:underline"
                        >
                          Track
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {completedTokens.length > 0 && (
        <section className="rounded-xl border border-slate-200 bg-white px-6 py-4">
          <h3 className="text-sm font-semibold text-slate-900">
            Recently Completed
          </h3>
          <div className="mt-2 flex flex-wrap gap-x-6 gap-y-2 text-xs text-slate-600">
            {completedTokens.map((tok) => (
              <span key={tok.id} className="tabular-nums">
                <span className="font-mono font-semibold text-slate-800">
                  {formatTokenLabel(tok.tokenNumber)}
                </span>{' '}
                · {tok.patientName}
              </span>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

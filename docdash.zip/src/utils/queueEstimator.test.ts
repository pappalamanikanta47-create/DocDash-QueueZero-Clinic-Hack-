import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateEWMA,
  calculateEstimatedWaitMinutes,
  computeTokenMetrics,
  haversineDistanceMeters,
  isWithinCheckInRadius,
  shouldTriggerProximityAlert,
} from './queueEstimator';
import type { Doctor, QueueToken } from '../types/clinic';

const sampleDoctor: Doctor = {
  id: 'doc-mehta',
  name: 'Dr. Aarav Mehta',
  credentials: 'MD, FACC',
  specialty: 'Cardiology',
  clinicId: 'clinic-metro',
  clinicName: 'MetroCare Central Clinic',
  consultationFee: 140,
  baseAvgMinutes: 12,
  dynamicAvgMinutes: 12,
  recentDurations: [11, 13, 12, 12, 12],
  status: 'In Consultation',
  delayOffsetMinutes: 0,
  shiftAvailability: ['Morning', 'Evening'],
};

function makeToken(
  tokenNumber: number,
  status: QueueToken['status'],
  priority: QueueToken['priority'] = 'normal',
  queueRank?: number
): QueueToken {
  return {
    id: `tok-${tokenNumber}`,
    doctorId: 'doc-mehta',
    clinicId: 'clinic-metro',
    tokenNumber,
    queueRank: queueRank ?? tokenNumber * 100,
    patientName: `Patient ${tokenNumber}`,
    patientPhone: '+1-555-0100',
    shift: 'Morning',
    status,
    priority,
    notes: '',
    prescriptionNotes: null,
    prescriptionFileName: null,
    prescriptionFileData: null,
    bookedAt: '2026-11-20T08:00:00Z',
    calledAt: null,
    completedAt: null,
    checkedInAt: null,
    checkInDistanceMeters: null,
  };
}

test('calculateEWMA adapts smoothly to last 5 consultations', () => {
  assert.equal(calculateEWMA([], 12), 12);
  assert.equal(calculateEWMA([12, 12, 12, 12, 12], 12), 12);
  // Heavy consultations push EWMA upward
  const slower = calculateEWMA([12, 18, 22, 24, 26], 12);
  assert.ok(slower > 18 && slower <= 26);
  // Clamps outliers to 5..30 range
  assert.equal(calculateEWMA([60, 60, 60, 60, 60], 15), 29);
});

test('Dr. Mehta Token #14 demo scenario computes 36m then 24m with amber alert', () => {
  const tok11 = makeToken(11, 'in_consultation');
  const tok12 = makeToken(12, 'waiting');
  const tok13 = makeToken(13, 'waiting');
  const tok14 = makeToken(14, 'waiting');

  const initialMetrics = computeTokenMetrics(tok14, sampleDoctor, [
    tok11,
    tok12,
    tok13,
    tok14,
  ]);
  assert.equal(initialMetrics.activeTokenNumber, 11);
  assert.equal(initialMetrics.patientsAhead, 3);
  assert.equal(initialMetrics.estimatedWaitMinutes, 36);
  assert.equal(initialMetrics.isProximityAlert, false);

  // Doctor clicks "Call Next Patient": #11 completed, #12 in consultation
  tok11.status = 'completed';
  tok12.status = 'in_consultation';

  const updatedMetrics = computeTokenMetrics(tok14, sampleDoctor, [
    tok11,
    tok12,
    tok13,
    tok14,
  ]);
  assert.equal(updatedMetrics.activeTokenNumber, 12);
  assert.equal(updatedMetrics.patientsAhead, 2);
  assert.equal(updatedMetrics.estimatedWaitMinutes, 24);
  assert.equal(updatedMetrics.isProximityAlert, true);
});

test('Doctor delay offset and emergency escalation recalculate wait times accurately', () => {
  const tok12 = makeToken(12, 'in_consultation');
  const tok13 = makeToken(13, 'waiting');
  const tok14 = makeToken(14, 'waiting');
  const emergency = makeToken(15, 'waiting', 'emergency', 1250); // inserted before #13 (1300)

  const delayedDoctor: Doctor = {
    ...sampleDoctor,
    status: 'Delayed',
    delayOffsetMinutes: 10,
  };

  const metricsWithEmergencyAndDelay = computeTokenMetrics(
    tok14,
    delayedDoctor,
    [tok12, emergency, tok13, tok14]
  );
  // Ahead of #14: #12 (active), emergency, #13 => 3 patients * 12 + 10 = 46 mins
  assert.equal(metricsWithEmergencyAndDelay.patientsAhead, 3);
  assert.equal(metricsWithEmergencyAndDelay.estimatedWaitMinutes, 46);
});

test('shouldTriggerProximityAlert triggers strictly for 1 or 2 patients ahead', () => {
  assert.equal(shouldTriggerProximityAlert(3, 'waiting'), false);
  assert.equal(shouldTriggerProximityAlert(2, 'waiting'), true);
  assert.equal(shouldTriggerProximityAlert(1, 'checked_in'), true);
  assert.equal(shouldTriggerProximityAlert(0, 'in_consultation'), false);
  assert.equal(shouldTriggerProximityAlert(1, 'skipped'), false);
});

test('calculateEstimatedWaitMinutes returns 0 for non-waiting states', () => {
  assert.equal(calculateEstimatedWaitMinutes(2, 12, 10, 'completed'), 0);
  assert.equal(calculateEstimatedWaitMinutes(0, 12, 10, 'in_consultation'), 0);
  assert.equal(calculateEstimatedWaitMinutes(2, 12, 10, 'waiting'), 34);
});

test('haversineDistanceMeters and 500m geolocation check-in validation', () => {
  const clinicLat = 40.7505;
  const clinicLon = -73.9934;
  // ~220m away
  const closeDistance = haversineDistanceMeters(
    clinicLat,
    clinicLon,
    40.7525,
    -73.9934
  );
  assert.ok(closeDistance > 150 && closeDistance < 300);
  assert.equal(isWithinCheckInRadius(closeDistance), true);

  // ~1.5km away
  const farDistance = haversineDistanceMeters(
    clinicLat,
    clinicLon,
    40.764,
    -73.9934
  );
  assert.ok(farDistance > 1000);
  assert.equal(isWithinCheckInRadius(farDistance), false);
});

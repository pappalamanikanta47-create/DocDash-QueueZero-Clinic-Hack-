import type { Doctor, QueueToken, TokenStatus } from '../types/clinic';

export const CHECK_IN_RADIUS_METERS = 500;
export const PROXIMITY_ALERT_TOKEN_THRESHOLD = 2;

/**
 * Exponentially Weighted Moving Average (EWMA) over up to the last 5 consultations.
 * Adapts dynamically when individual consultations range from 5 to 30 minutes.
 */
export function calculateEWMA(
  recentDurations: number[],
  baselineMinutes: number,
  alpha = 0.4
): number {
  const safeBaseline = Math.min(30, Math.max(5, Math.round(baselineMinutes)));
  const window = recentDurations
    .filter((d) => Number.isFinite(d) && d > 0)
    .slice(-5)
    .map((d) => Math.min(30, Math.max(5, d)));

  if (window.length === 0) {
    return safeBaseline;
  }

  let ewma = safeBaseline;
  for (const duration of window) {
    ewma = alpha * duration + (1 - alpha) * ewma;
  }

  return Math.min(30, Math.max(5, Math.round(ewma)));
}

/**
 * Sorts waiting/checked-in tokens in active queue order.
 */
export function getOrderedWaitingTokens(
  doctorId: string,
  tokens: QueueToken[]
): QueueToken[] {
  return tokens
    .filter(
      (t) =>
        t.doctorId === doctorId &&
        (t.status === 'waiting' || t.status === 'checked_in')
    )
    .sort((a, b) => {
      if (a.queueRank !== b.queueRank) {
        return a.queueRank - b.queueRank;
      }
      return a.tokenNumber - b.tokenNumber;
    });
}

export function getActiveConsultationToken(
  doctorId: string,
  tokens: QueueToken[]
): QueueToken | null {
  return (
    tokens.find(
      (t) => t.doctorId === doctorId && t.status === 'in_consultation'
    ) ?? null
  );
}

export function getNextInLineToken(
  doctorId: string,
  tokens: QueueToken[]
): QueueToken | null {
  const waiting = getOrderedWaitingTokens(doctorId, tokens);
  return waiting[0] ?? null;
}

export interface TokenQueueMetrics {
  patientsAhead: number;
  queuePosition: number;
  estimatedWaitMinutes: number;
  isProximityAlert: boolean;
  activeTokenNumber: number | null;
}

/**
 * Computes queue position and predicted wait time for a specific token:
 * EstimatedWait = (PatientsAhead) * DynamicAverageDuration + DoctorOffsetDelay
 * Note: When an active consultation is in progress, Token #14 with #11 active
 * and #12, #13 waiting has patientsAhead = 3 (1 active + 2 waiting ahead),
 * matching (14 - 11) * 12 = 36 minutes.
 */
export function computeTokenMetrics(
  token: QueueToken,
  doctor: Doctor,
  allTokens: QueueToken[]
): TokenQueueMetrics {
  const activeToken = getActiveConsultationToken(doctor.id, allTokens);
  const activeTokenNumber = activeToken ? activeToken.tokenNumber : null;

  if (
    token.status === 'in_consultation' ||
    token.status === 'completed' ||
    token.status === 'skipped'
  ) {
    return {
      patientsAhead: 0,
      queuePosition: 0,
      estimatedWaitMinutes: 0,
      isProximityAlert: false,
      activeTokenNumber,
    };
  }

  const waiting = getOrderedWaitingTokens(doctor.id, allTokens);
  const waitingIndex = waiting.findIndex((t) => t.id === token.id);
  const aheadInWaiting = waitingIndex >= 0 ? waitingIndex : waiting.length;
  const activeOffset = activeToken ? 1 : 0;
  const patientsAhead = activeOffset + aheadInWaiting;
  const queuePosition = patientsAhead + 1;

  const estimatedWaitMinutes = calculateEstimatedWaitMinutes(
    patientsAhead,
    doctor.dynamicAvgMinutes,
    doctor.delayOffsetMinutes,
    token.status
  );

  return {
    patientsAhead,
    queuePosition,
    estimatedWaitMinutes,
    isProximityAlert: shouldTriggerProximityAlert(patientsAhead, token.status),
    activeTokenNumber,
  };
}

export function calculateEstimatedWaitMinutes(
  patientsAhead: number,
  dynamicAvgMinutes: number,
  doctorOffsetDelay: number,
  status: TokenStatus
): number {
  if (
    status === 'in_consultation' ||
    status === 'completed' ||
    status === 'skipped'
  ) {
    return 0;
  }
  const safeAhead = Math.max(0, patientsAhead);
  const safeAvg = Math.max(1, dynamicAvgMinutes);
  const safeDelay = Math.max(0, doctorOffsetDelay);
  return Math.round(safeAhead * safeAvg + safeDelay);
}

export function shouldTriggerProximityAlert(
  patientsAhead: number,
  status: TokenStatus
): boolean {
  if (status !== 'waiting' && status !== 'checked_in') {
    return false;
  }
  return patientsAhead > 0 && patientsAhead <= PROXIMITY_ALERT_TOKEN_THRESHOLD;
}

/**
 * Haversine distance between two WGS-84 coordinates in meters.
 */
export function haversineDistanceMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const earthRadiusMeters = 6371000;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(earthRadiusMeters * c);
}

export function isWithinCheckInRadius(
  distanceMeters: number,
  maxRadiusMeters = CHECK_IN_RADIUS_METERS
): boolean {
  return Number.isFinite(distanceMeters) && distanceMeters <= maxRadiusMeters;
}

export function formatTokenLabel(tokenNumber: number | null): string {
  if (tokenNumber === null || !Number.isFinite(tokenNumber)) {
    return '—';
  }
  return `#${String(tokenNumber).padStart(2, '0')}`;
}

import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import { ClinicDatabase } from './src/db/database.ts';
import type { ClinicAppState, DoctorStatus, ShiftType } from './src/types/clinic.ts';

const PORT = 3000;

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '6mb' }));

  const db = new ClinicDatabase();
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  function broadcastState(state: ClinicAppState) {
    const payload = JSON.stringify({ type: 'state:updated', data: state });
    for (const client of wss.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    }
  }

  wss.on('connection', (socket) => {
    socket.send(
      JSON.stringify({
        type: 'state:init',
        data: db.getFullState(),
      })
    );
  });

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, time: new Date().toISOString() });
  });

  app.get('/api/state', (_req, res) => {
    res.json(db.getFullState());
  });

  app.post('/api/tokens', (req, res) => {
    try {
      const { doctorId, patientName, patientPhone, shift, notes } = req.body as {
        doctorId: string;
        patientName: string;
        patientPhone: string;
        shift: ShiftType;
        notes?: string;
      };
      if (!doctorId || !patientName?.trim() || !patientPhone?.trim()) {
        return res.status(400).json({
          error: 'Please enter patient name, phone number, and select a doctor.',
        });
      }
      const result = db.bookToken({
        doctorId,
        patientName,
        patientPhone,
        shift: shift === 'Evening' ? 'Evening' : 'Morning',
        notes,
        priority: 'normal',
      });
      broadcastState(result.state);
      return res.status(201).json(result);
    } catch (error) {
      return res.status(400).json({
        error: error instanceof Error ? error.message : 'Booking failed',
      });
    }
  });

  app.post('/api/tokens/emergency', (req, res) => {
    try {
      const { doctorId, patientName, patientPhone, shift, notes } = req.body as {
        doctorId: string;
        patientName: string;
        patientPhone: string;
        shift?: ShiftType;
        notes?: string;
      };
      if (!doctorId || !patientName?.trim()) {
        return res.status(400).json({
          error: 'Doctor and emergency patient name are required.',
        });
      }
      const result = db.bookToken({
        doctorId,
        patientName,
        patientPhone: patientPhone?.trim() || 'Triage Desk',
        shift: shift === 'Evening' ? 'Evening' : 'Morning',
        notes: notes || 'Urgent triage escalation',
        priority: 'emergency',
      });
      broadcastState(result.state);
      return res.status(201).json(result);
    } catch (error) {
      return res.status(400).json({
        error: error instanceof Error ? error.message : 'Emergency escalation failed',
      });
    }
  });

  app.post('/api/doctors/:id/call-next', (req, res) => {
    try {
      const { durationMinutes } = (req.body || {}) as {
        durationMinutes?: number;
      };
      const state = db.callNextPatient(req.params.id, durationMinutes);
      broadcastState(state);
      return res.json(state);
    } catch (error) {
      return res.status(400).json({
        error: error instanceof Error ? error.message : 'Could not advance queue',
      });
    }
  });

  app.post('/api/doctors/:id/complete-current', (req, res) => {
    try {
      const {
        durationMinutes,
        prescriptionNotes,
        prescriptionFileName,
        prescriptionFileData,
      } = (req.body || {}) as {
        durationMinutes?: number;
        prescriptionNotes?: string;
        prescriptionFileName?: string | null;
        prescriptionFileData?: string | null;
      };
      const state = db.markCurrentCompleted({
        doctorId: req.params.id,
        durationMinutes,
        prescriptionNotes,
        prescriptionFileName,
        prescriptionFileData,
      });
      broadcastState(state);
      return res.json(state);
    } catch (error) {
      return res.status(400).json({
        error: error instanceof Error ? error.message : 'Could not mark completed',
      });
    }
  });

  app.post('/api/doctors/:id/delay', (req, res) => {
    try {
      const { minutes } = (req.body || {}) as { minutes?: number };
      const state = db.addDelay(req.params.id, minutes ?? 10);
      broadcastState(state);
      return res.json(state);
    } catch (error) {
      return res.status(400).json({
        error: error instanceof Error ? error.message : 'Could not apply delay',
      });
    }
  });

  app.post('/api/doctors/:id/status', (req, res) => {
    try {
      const { status, resetDelay } = req.body as {
        status: DoctorStatus;
        resetDelay?: boolean;
      };
      const state = db.updateDoctorStatus(req.params.id, status, Boolean(resetDelay));
      broadcastState(state);
      return res.json(state);
    } catch (error) {
      return res.status(400).json({
        error: error instanceof Error ? error.message : 'Could not update status',
      });
    }
  });

  app.post('/api/tokens/:id/skip', (req, res) => {
    try {
      const state = db.skipAbsentToken(req.params.id);
      broadcastState(state);
      return res.json(state);
    } catch (error) {
      return res.status(400).json({
        error: error instanceof Error ? error.message : 'Could not skip token',
      });
    }
  });

  app.post('/api/tokens/:id/requeue', (req, res) => {
    try {
      const state = db.requeueSkippedToken(req.params.id);
      broadcastState(state);
      return res.json(state);
    } catch (error) {
      return res.status(400).json({
        error: error instanceof Error ? error.message : 'Could not requeue token',
      });
    }
  });

  app.post('/api/tokens/:id/checkin', (req, res) => {
    try {
      const { latitude, longitude } = req.body as {
        latitude: number;
        longitude: number;
      };
      if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
        return res.status(400).json({ error: 'Valid GPS coordinates are required.' });
      }
      const result = db.checkInTokenByGeolocation(
        req.params.id,
        latitude,
        longitude
      );
      if (result.checkedIn) {
        broadcastState(result.state);
        return res.json(result);
      }
      return res.status(400).json({
        error: `You are ${result.distanceMeters}m away. Virtual check-in activates within 500m of the clinic.`,
        distanceMeters: result.distanceMeters,
        checkedIn: false,
      });
    } catch (error) {
      return res.status(400).json({
        error: error instanceof Error ? error.message : 'Check-in failed',
      });
    }
  });

  app.post('/api/tokens/:id/prescription', (req, res) => {
    try {
      const { prescriptionNotes, prescriptionFileName, prescriptionFileData } =
        req.body as {
          prescriptionNotes: string;
          prescriptionFileName?: string | null;
          prescriptionFileData?: string | null;
        };
      const state = db.attachPrescription({
        tokenId: req.params.id,
        prescriptionNotes: prescriptionNotes || '',
        prescriptionFileName,
        prescriptionFileData,
      });
      broadcastState(state);
      return res.json(state);
    } catch (error) {
      return res.status(400).json({
        error: error instanceof Error ? error.message : 'Failed to attach summary',
      });
    }
  });

  app.post('/api/demo/reset', (_req, res) => {
    const state = db.resetToSeed();
    broadcastState(state);
    return res.json(state);
  });

  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`DocDash: QueueZero server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
